<?php

    include_once './common_html_php_code/header.php';

    if (isset($_POST['submit'])) {

        $stmt = mysqli_prepare($conn, "UPDATE student_master SET passwd = MD5(?) WHERE roll_no=?");
        if ($stmt) {
            mysqli_stmt_bind_param($stmt, "ss", $_POST['passwd'], $_SESSION['student_id']);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_close($stmt);
            $_SESSION['success_msg'] = "Password updated successfully!";
        }
        else{
            $_SESSION['error_msg'] = (string)$conn->error;
        }                        
    } 
    ShowSessionMsg();
?>
    <h1 class="h2">Change Password</h1>        
    <form method="post" action="<?php echo $_SERVER['PHP_SELF'] ?>" name="edit_passwd" onsubmit="return chkForm();">           
        <div class="form-group">
            <label class="control-label col-sm-2">New Password</label>
            <div class="col-sm-4">
                <input type="password" class="form-control" id="id_password" name="passwd" placeholder="Enter password" />
            </div>
        </div>                            
        <div class="form-group">
            <div class="col-sm-offset-2 col-sm-4">
                <button type="submit" class="btn btn-default" name="submit" id="id_submit" value="Update">Update</button>
            </div>
        </div>
    </form>
                        
<?php           
    include_once './common_html_php_code/footer.php';
?>
                    
<script language="javascript" type="text/javascript">
    function chkForm(form)
    {
        if ($("#id_password").val().length < 1 )
        {
            alert("Enter New password");
            $("#id_password").focus();
            return false;
        }
    }
</script>