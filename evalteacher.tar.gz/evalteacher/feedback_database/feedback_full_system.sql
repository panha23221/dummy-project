-- phpMyAdmin SQL Dump
-- version 4.9.5deb2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jul 25, 2021 at 07:29 PM
-- Server version: 8.0.25-0ubuntu0.20.04.1
-- PHP Version: 7.3.7-1+ubuntu16.04.1+deb.sury.org+1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `feedback_full`
--

-- --------------------------------------------------------

--
-- Table structure for table `batch_master`
--

CREATE TABLE `batch_master` (
  `batch_id` int NOT NULL,
  `batch_name` varchar(255) NOT NULL,
  `feedback_no` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `batch_master`
--

INSERT INTO `batch_master` (`batch_id`, `batch_name`, `feedback_no`) VALUES
(3, '2016-17', 1),
(4, '2017-18', 1),
(7, '2018-19', 1);

-- --------------------------------------------------------

--
-- Table structure for table `branch_master`
--

CREATE TABLE `branch_master` (
  `b_id` int NOT NULL,
  `b_name` varchar(255) NOT NULL,
  `college_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `branch_master`
--

INSERT INTO `branch_master` (`b_id`, `b_name`, `college_id`) VALUES
(1, 'CE - Civil Engineering', 1),
(2, 'ITE - Information Technology Engineering', 1),
(3, 'ME - Mechanical Engineering', 1),
(4, 'EE - Electrical Engineering', 1),
(5, 'ECE - Electronics and Communication Engineering', 1),
(6, 'CSE - Computer Science Engineering', 1),
(8, 'AC - Accounting - I', 2);

-- --------------------------------------------------------

--
-- Table structure for table `college_master`
--

CREATE TABLE `college_master` (
  `c_id` int NOT NULL,
  `c_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `college_master`
--

INSERT INTO `college_master` (`c_id`, `c_name`) VALUES
(1, 'I2IT'),
(2, 'CHARUSAT'),
(4, 'DDIT');

-- --------------------------------------------------------

--
-- Table structure for table `division_master`
--

CREATE TABLE `division_master` (
  `id` int NOT NULL,
  `division` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `division_master`
--

INSERT INTO `division_master` (`id`, `division`) VALUES
(1, 'Class A'),
(2, 'Class B'),
(4, 'Class C');

-- --------------------------------------------------------

--
-- Table structure for table `faculty_master`
--

CREATE TABLE `faculty_master` (
  `f_id` int NOT NULL,
  `f_name` varchar(255) NOT NULL,
  `l_name` varchar(255) NOT NULL,
  `c_id` int NOT NULL COMMENT 'college_id'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `faculty_master`
--

INSERT INTO `faculty_master` (`f_id`, `f_name`, `l_name`, `c_id`) VALUES
(1, 'Mr. Nilesh', 'Deshmukh', 1),
(2, 'Mr. Rayan', 'Goudar', 1),
(3, 'Ms.Sahana', 'Bhosale', 1),
(4, 'Dr. Bharat', 'Chaudary', 1),
(5, 'Mr. Ravindra', 'Joshi', 1),
(6, 'Ms. Shraddha', 'Kakartkar', 1),
(7, 'Ms. Anagha', 'Komawar', 1),
(8, 'Mr. Shrenik', 'Patel', 1),
(9, 'Mr. Hello', 'Brother', 2),
(10, 'Ms. Vijaya', 'Lakshmi', 2),
(11, 'Ms. Vijaya', 'Lakshmi', 1);

-- --------------------------------------------------------

--
-- Table structure for table `feedback_master`
--

CREATE TABLE `feedback_master` (
  `feed_id` int NOT NULL,
  `roll_no` varchar(255) NOT NULL,
  `college_id` int NOT NULL COMMENT 'college-id',
  `b_id` int NOT NULL,
  `batch_id` int NOT NULL,
  `feedback_no` int NOT NULL,
  `sem_id` int NOT NULL,
  `f_id` int NOT NULL,
  `sub_id` int NOT NULL,
  `division_id` int NOT NULL,
  `ans1` int NOT NULL,
  `ans2` int NOT NULL,
  `ans3` int NOT NULL,
  `ans4` int NOT NULL,
  `ans5` int NOT NULL,
  `ans6` int NOT NULL,
  `ans7` int NOT NULL,
  `ans8` int NOT NULL,
  `ans9` int NOT NULL,
  `ans10` int NOT NULL,
  `ans11` int NOT NULL,
  `ans12` int NOT NULL,
  `ans13` int NOT NULL,
  `ans14` int NOT NULL,
  `ans15` int NOT NULL,
  `remark` text NOT NULL,
  `feed_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `feedback_master`
--

INSERT INTO `feedback_master` (`feed_id`, `roll_no`, `college_id`, `b_id`, `batch_id`, `feedback_no`, `sem_id`, `f_id`, `sub_id`, `division_id`, `ans1`, `ans2`, `ans3`, `ans4`, `ans5`, `ans6`, `ans7`, `ans8`, `ans9`, `ans10`, `ans11`, `ans12`, `ans13`, `ans14`, `ans15`, `remark`, `feed_date`) VALUES
(1, '573CS17001', 1, 6, 7, 1, 1, 1, 1, 1, 3, 4, 3, 4, 4, 5, 5, 4, 4, 4, 0, 0, 0, 0, 0, 'sadas', '2019-04-13 00:00:00'),
(2, '900AC19001', 4, 8, 7, 1, 1, 11, 20, 1, 4, 3, 4, 5, 4, 3, 4, 3, 3, 4, 0, 0, 0, 0, 0, 'hello', '2019-04-14 00:00:00'),
(3, '573CS17001', 1, 6, 7, 1, 1, 10, 19, 1, 3, 4, 5, 4, 3, 4, 5, 4, 3, 3, 0, 0, 0, 0, 0, 'dfsfds', '2019-04-14 00:00:00'),
(4, '573CS17002', 1, 6, 7, 1, 1, 1, 1, 1, 3, 2, 3, 4, 5, 3, 3, 4, 3, 4, 0, 0, 0, 0, 0, 'fsdfs', '2019-04-14 00:00:00'),
(5, '573CS17001', 1, 6, 7, 1, 1, 2, 4, 1, 3, 4, 3, 4, 5, 3, 4, 3, 3, 3, 0, 0, 0, 0, 0, 'test', '2019-05-03 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `feedback_ques_master`
--

CREATE TABLE `feedback_ques_master` (
  `q_id` int NOT NULL,
  `ques` varchar(255) NOT NULL,
  `one_word` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `feedback_ques_master`
--

INSERT INTO `feedback_ques_master` (`q_id`, `ques`, `one_word`) VALUES
(1, 'Faculty was punctual in class.', 'Punctual '),
(2, 'Faculty was well prepared for the classes.', 'Prepared'),
(3, 'Faculty communication skill were good.', 'Communication '),
(4, 'Teaching methodology was good.', 'Methodology '),
(5, 'Faculty had clearly defined objectives for each class.', 'Objectives'),
(6, 'Faculty adequately cleared all my doubts and was helpful in solving queries.', 'Solving'),
(7, 'Faculty treated me with respect and aided in my learning.', 'Respect '),
(8, 'Faculty was instrumental in the value addition process.', 'Value_Add'),
(9, 'In my opinion the same faculty should be continued for such subjects.', 'Be_continued'),
(10, 'Faculty was punctual in class.', 'Que10');

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE `members` (
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `members`
--

INSERT INTO `members` (`username`, `password`) VALUES
('admin', '827ccb0eea8a706c4c34a16891f84e7b');

-- --------------------------------------------------------

--
-- Table structure for table `semester_master`
--

CREATE TABLE `semester_master` (
  `sem_id` int NOT NULL,
  `sem_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `semester_master`
--

INSERT INTO `semester_master` (`sem_id`, `sem_name`) VALUES
(1, 'I'),
(2, 'II'),
(3, 'III'),
(4, 'IV'),
(5, 'V'),
(6, 'VI'),
(7, 'VII'),
(8, 'VIII');

-- --------------------------------------------------------

--
-- Table structure for table `student_master`
--

CREATE TABLE `student_master` (
  `id` int NOT NULL,
  `roll_no` varchar(255) NOT NULL,
  `passwd` varchar(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email_id` varchar(255) NOT NULL,
  `college_id` int NOT NULL,
  `batch_id` int DEFAULT NULL,
  `branch_id` int DEFAULT NULL,
  `sem_id` int DEFAULT NULL,
  `division_id` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `student_master`
--

INSERT INTO `student_master` (`id`, `roll_no`, `passwd`, `first_name`, `last_name`, `email_id`, `college_id`, `batch_id`, `branch_id`, `sem_id`, `division_id`) VALUES
(1, '111CE19001', '13f01fa3c8facb5ce0e523d257574a1c', 'Rey', 'W', 'rey@w.com', 1, 7, 6, 1, 1),
(2, '111CE19002', '25fc5f536157c99afd04fc0a7f2155d7', 'Hiru', 'Jo', 'hiru@jo.com', 1, 7, 6, 1, 1),
(4, '573CS17001', '5125c398fb2c50ffb630def2aba9238b', 'bilo', 'gilo', '', 1, 7, 6, 1, 1),
(5, '573CS17002', 'fb05455cbaa2e427fc59ea4262c3a44c', 'hello', 'Gupta', 'rohan@k.com', 1, 7, 6, 1, 1),
(6, '573CS17003', 'c7b563d08ce7f9ae7f396d564ef73d52', 'Soham', 'M', 'soham@.m', 1, 7, 6, 1, 1),
(7, '573CS17004', 'fb8c02be852f7fce410fb55eedf681c9', 'Yasir', 'C', 'yasir@c.com', 1, 7, 6, 1, 1),
(8, '573CS17005', '90cd662adfcd3db6ca34a37f8d653168', 'Reha', 'P', 'reha@p.com', 1, 7, 6, 1, 1),
(9, '573CS17006', '69a8aeecb3755460f55d3d44d350b53c', 'Kunj', 'P', 'kunj@p.com', 1, 7, 6, 1, 1),
(10, '573CS17007', '72a09f20735034aac2becd59ec9d11fc', 'Suhana', 'K', 'suhana@k.com', 1, 7, 6, 1, 1),
(11, '573CS17008', '37d1a2b7d410c14f6fbc049dcb002cf8', 'Himja', 'P', 'himja@p.com', 1, 7, 6, 1, 1),
(12, '573CS17009', 'c89c11793256bca9d3c5221695431dc8', 'Bhavani', 'K', 'bhavin@k.com', 1, 7, 6, 1, 1),
(13, '900AC19001', 'f7eb97be856952a607b5e5a68b4363b6', 'Mihir', 'V', 'mihir@V.com', 4, 7, 8, 1, 1),
(14, '900AC19002', 'a423d6ed5534ef38305fce631c492ec1', 'Hemant', 'P', 'hemant@jo.com', 4, 7, 8, 1, 1),
(15, '900AC19003', '30b4ab3f779ce42127f6c92b247b7481', 'Bhola', 'P', 'bhola@p.com', 4, 7, 8, 1, 1),
(16, '900AC19004', '324fb7e535df81e5f5a3495c91c3e43d', 'Sanjeev', 'K', 'sanjeev@k.com', 4, 7, 8, 1, 1),
(17, '900AC19005', '5423f270e560e34e85431054a10d593d', 'Usha', 'J', 'usha@j.com', 4, 7, 8, 1, 1),
(18, '573CS18001', '8c865fe9e99bb64070e6e39a8d381a34', 'Rey', 'W', 'rey@w.com', 1, 3, 3, 1, 1),
(19, '573CS18002', '9a1e0e8e4f5fb7c33bc6e82d96ac168e', 'Hiru', 'Jo', 'hiru@jo.com', 1, 3, 3, 1, 1),
(20, '573CS18003', '6fe0a230317c84a10a7874f4390b7eec', 'Binu', 'A', 'binu@a.com', 1, 3, 3, 1, 1),
(21, '573CS18004', '651f176e156d0ccfdacd00f78b71dd08', 'Mogu', 'Jo', 'mogu@jo.com', 1, 3, 3, 1, 1),
(22, '573CS18005', '05fe8f34a6b4199027234db8956e7875', 'Nalu', 'K', 'nalu@k.co', 1, 3, 3, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `subject_master`
--

CREATE TABLE `subject_master` (
  `sub_id` int NOT NULL,
  `sub_name` varchar(255) NOT NULL,
  `sem_id` int NOT NULL,
  `f_id` int NOT NULL,
  `branch_id` int NOT NULL COMMENT 'branch-id',
  `batch_id` int NOT NULL,
  `division_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `subject_master`
--

INSERT INTO `subject_master` (`sub_id`, `sub_name`, `sem_id`, `f_id`, `branch_id`, `batch_id`, `division_id`) VALUES
(1, 'Engineering Mathematics â€“ I', 1, 1, 6, 7, 1),
(2, 'Engineering Mathematics â€“ I', 1, 1, 6, 7, 2),
(3, 'C & C++', 2, 1, 6, 7, 1),
(4, 'Microprocessors', 1, 2, 6, 7, 1),
(5, 'Microprocessors', 2, 2, 6, 7, 2),
(6, 'Wireless Comm.', 1, 4, 5, 4, 1),
(7, 'Wireless LAN', 1, 4, 5, 4, 1),
(8, 'CCN', 1, 5, 5, 2, 1),
(9, 'ND&O', 2, 5, 5, 2, 2),
(10, 'Database', 1, 7, 2, 2, 1),
(11, 'C & C++', 2, 1, 6, 7, 2),
(12, 'Database', 1, 8, 6, 4, 1),
(13, 'Analysis of Algorithm', 1, 8, 6, 4, 2),
(15, 'Account', 1, 9, 8, 7, 1),
(17, 'Eng Design', 1, 1, 3, 7, 1),
(18, 'OS', 1, 1, 6, 7, 1),
(19, 'Communication trainning', 1, 10, 8, 7, 1),
(20, 'Communication trainning', 1, 11, 6, 7, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `batch_master`
--
ALTER TABLE `batch_master`
  ADD PRIMARY KEY (`batch_id`);

--
-- Indexes for table `branch_master`
--
ALTER TABLE `branch_master`
  ADD PRIMARY KEY (`b_id`),
  ADD KEY `college_id` (`college_id`);

--
-- Indexes for table `college_master`
--
ALTER TABLE `college_master`
  ADD PRIMARY KEY (`c_id`);

--
-- Indexes for table `division_master`
--
ALTER TABLE `division_master`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `faculty_master`
--
ALTER TABLE `faculty_master`
  ADD PRIMARY KEY (`f_id`);

--
-- Indexes for table `feedback_master`
--
ALTER TABLE `feedback_master`
  ADD PRIMARY KEY (`feed_id`),
  ADD KEY `FK_college_id` (`college_id`),
  ADD KEY `FK_b_id` (`b_id`),
  ADD KEY `FK_batch_id` (`batch_id`),
  ADD KEY `FK_sem_id` (`sem_id`),
  ADD KEY `FK_division_id` (`division_id`),
  ADD KEY `FK_f_id` (`f_id`),
  ADD KEY `FK_sub_id` (`sub_id`);

--
-- Indexes for table `feedback_ques_master`
--
ALTER TABLE `feedback_ques_master`
  ADD PRIMARY KEY (`q_id`);

--
-- Indexes for table `semester_master`
--
ALTER TABLE `semester_master`
  ADD PRIMARY KEY (`sem_id`);

--
-- Indexes for table `student_master`
--
ALTER TABLE `student_master`
  ADD PRIMARY KEY (`id`),
  ADD KEY `batch_id` (`batch_id`),
  ADD KEY `branch_id` (`branch_id`),
  ADD KEY `sem_id` (`sem_id`),
  ADD KEY `division_id` (`division_id`);

--
-- Indexes for table `subject_master`
--
ALTER TABLE `subject_master`
  ADD PRIMARY KEY (`sub_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `batch_master`
--
ALTER TABLE `batch_master`
  MODIFY `batch_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `branch_master`
--
ALTER TABLE `branch_master`
  MODIFY `b_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `college_master`
--
ALTER TABLE `college_master`
  MODIFY `c_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `division_master`
--
ALTER TABLE `division_master`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `faculty_master`
--
ALTER TABLE `faculty_master`
  MODIFY `f_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `feedback_master`
--
ALTER TABLE `feedback_master`
  MODIFY `feed_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `feedback_ques_master`
--
ALTER TABLE `feedback_ques_master`
  MODIFY `q_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `semester_master`
--
ALTER TABLE `semester_master`
  MODIFY `sem_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `student_master`
--
ALTER TABLE `student_master`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `subject_master`
--
ALTER TABLE `subject_master`
  MODIFY `sub_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `branch_master`
--
ALTER TABLE `branch_master`
  ADD CONSTRAINT `branch_master_ibfk_1` FOREIGN KEY (`college_id`) REFERENCES `college_master` (`c_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `branch_master_ibfk_2` FOREIGN KEY (`college_id`) REFERENCES `college_master` (`c_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `FK_CollegeMaster` FOREIGN KEY (`college_id`) REFERENCES `college_master` (`c_id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Constraints for table `feedback_master`
--
ALTER TABLE `feedback_master`
  ADD CONSTRAINT `FK_b_id` FOREIGN KEY (`b_id`) REFERENCES `branch_master` (`b_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `FK_batch_id` FOREIGN KEY (`batch_id`) REFERENCES `batch_master` (`batch_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `FK_college_id` FOREIGN KEY (`college_id`) REFERENCES `college_master` (`c_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `FK_division_id` FOREIGN KEY (`division_id`) REFERENCES `division_master` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `FK_f_id` FOREIGN KEY (`f_id`) REFERENCES `faculty_master` (`f_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `FK_sem_id` FOREIGN KEY (`sem_id`) REFERENCES `semester_master` (`sem_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `FK_sub_id` FOREIGN KEY (`sub_id`) REFERENCES `subject_master` (`sub_id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Constraints for table `student_master`
--
ALTER TABLE `student_master`
  ADD CONSTRAINT `student_master_ibfk_1` FOREIGN KEY (`batch_id`) REFERENCES `batch_master` (`batch_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `student_master_ibfk_2` FOREIGN KEY (`branch_id`) REFERENCES `branch_master` (`b_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `student_master_ibfk_3` FOREIGN KEY (`sem_id`) REFERENCES `semester_master` (`sem_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `student_master_ibfk_4` FOREIGN KEY (`division_id`) REFERENCES `division_master` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
