<?php 
    include_once '../common_html_php_code/header.php';

    $action = (int)((isset($_GET['action'])) ? sanitize($conn, $_GET['action']): ADD_ACTION);
    $batch_name = '';
    if($action == DELETE_ACTION){    
        delete_record($_GET, $conn, "batch_master", "batch_id", "batch.php");
        exit();
        
    }else if($action == UPDATE_ACTION){
        $batch_id = (isset($_GET['id'])) ? sanitize($conn, $_GET['id']): 0;
        $result = mysqli_query($conn, "SELECT * FROM batch_master WHERE batch_id='$batch_id' ");
        while($myrow = mysqli_fetch_assoc($result))
        {
            $batch_name = $myrow["batch_name"];
            $batch_id = $myrow['batch_id'];
        }
    }
    
   
    if(isset($_POST['submit']))
    {
        $batch_name = array_key_exists('batch_name', $_POST) ? sanitize($conn, $_POST['batch_name']) : '';
        $batch_id = array_key_exists('batch_id', $_POST) ? sanitize($conn, $_POST['batch_id']) : '';
        $feedback_no = array_key_exists('feedback_no', $_POST) ? sanitize($conn, $_POST['feedback_no']) : 1;
        $action = sanitize($conn, $_POST['submit']);
        
        
        if(empty($batch_name)){
            $_SESSION['error_msg'] = "Please enter batch name.";            
        }
        else{
            if($action == ADD_ACTION){
                $dup="select * from batch_master where batch_name='".$batch_name."'";
                $dup_res=mysqli_query($conn, $dup) or die(mysqli_error($conn));
                if(mysqli_num_rows($dup_res)==1)
                {                
                    $_SESSION['error_msg'] = "Batch name is already available in database.";
                }
                else
                {
                    //run the query which adds the data gathered from the form into the database
                    mysqli_query($conn, "INSERT INTO batch_master (batch_name,feedback_no) VALUES ('$batch_name','1')");
                    $_SESSION['success_msg'] = "Batch is added Successfully!";                
                    header( "refresh:0;url=batch.php" );
                    exit();                                            
                }
            }
            else if($action == UPDATE_ACTION){
                //check duplication
                $dup="select * from batch_master where batch_name='".$batch_name."' and batch_id!=".$_POST['batch_id'];
                $dup_res=mysqli_query($conn, $dup) or die(mysqli_error($conn));
                if(mysqli_num_rows($dup_res)==1)
                {
                    $_SESSION['error_msg'] = "Batch name is already available in database.";                
                }
                else
                {                                                                                    
                    $result = mysqli_query($conn, "UPDATE batch_master SET batch_name='$batch_name', feedback_no='$feedback_no' WHERE batch_id='$batch_id'");                
                    $_SESSION['success_msg'] = "Batch is updated successfully!";            
                    header( "refresh:0;url=batch.php" );
                    exit();
                }
            }
        }
    }
    
    ShowSessionMsg();
    include_once 'batch_form.php';
    include_once '../common_html_php_code/footer.php';
?>
<script language="javascript" type="text/javascript">
    function chkForm()
    {
        if ( $("#id_batch_name").val().length < 1 )
        {
            alert("Enter batch name");	
            $("#id_batch_name").focus();		
            return false;
        }            
    }
</script>