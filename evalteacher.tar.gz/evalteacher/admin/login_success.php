<?php 
    include_once '../common_html_php_code/header.php';
    ShowSessionMsg();
?>
    <p><br/>
    Info:</p>
    <p>Structure of the institute  </p>
    <p>College -> Branch -> Batch -> Semester -> Division -> Faculty -> Subject  </p>
    <p>So You can Add/Edit/Delete to College, Branch, Batch, Semester, Division, Faculty & Subject</p>
    <p>Example:</p>
    <ul>
        <li>College: Indian College</li>
        <li>Branch: Network and Telecommunication  </li>
        <li>Batch: August '08  </li>
        <li>Faculty: 
            <ul>
                <li>Rajesh Mishra </li>
                <li>Mohan Das</li>
            </ul>  
        </li>
        <li>Subject: 
            <ul>
                <li>Routing Protocol taught by Rajesh Mishra in Semester (I) & Division (Class A)</li>
                <li>Computer Networks taught by Mohan Das in Semester (II) & Division (Class B)</li>
            </ul>                                   
        </li>
    </ul>
    <p>Upload student detail CSV file from &quot;<strong>Import Student ID</strong>&quot; with college, branch, batch, semester & division </p>
    <p>To get the result(graph/excel) click on &quot;<strong>Feedback</strong>&quot; link.  </p>
    <p>Feedback Questions: You can change  by editing it.  </p>
    <p>Students will rate the Subject's faculty within the range of 1 - <?php echo $MAX_RATING; ?></p>
    <p>Graph will be generated according to the number of student and their rating. on "<b>Feedback</b>" </p>
    <p>You can take backup of your database.</p>
<?php
    include_once '../common_html_php_code/footer.php';
?>