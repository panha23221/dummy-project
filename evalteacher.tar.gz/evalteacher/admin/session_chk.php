<?php
//////////////////////////////////////////////////////////////////*****/////////////////////////////////////////////////////////////////////////////////////
  //                                                             Feedback Pro v1																			 //
  //														Faculty Evaluation System																		 //
  //														Developed By Shrenik Patel																		 //			
  //															 July 27, 2009																				 //
  //																																						 //		
  //  Tis program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by 				 //
  //  the Free Software  Foundation; either version 2 of the License, or (at your option) any later version.												 //
  //																																						 //
  //  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or      //
  //  FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.																 //
  //																																						 //
  //////////////////////////////////////////////////////////////////*****//////////////////////////////////////////////////////////////////////////////////////
session_start();
ob_start();
if (strpos($_SERVER['REQUEST_URI'], "/admin/")!== false) {
    if(!isset($_SESSION['myusername']) && basename($_SERVER['PHP_SELF']) != 'index.php')
    {
        header("location:index.php");
    }
}
else{
    if(!isset($_SESSION['student_id']) && basename($_SERVER['PHP_SELF']) != 'index.php')
    {
        header("location:index.php");
    }
}
?>
