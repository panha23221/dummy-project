<?php 
    include_once '../common_html_php_code/header.php';
    
    $action = (int)((isset($_GET['action'])) ? sanitize($conn, $_GET['action']): ADD_ACTION);
    $division = '';
    if($action == DELETE_ACTION){    
        delete_record($_GET, $conn, "division_master", "id", "division.php");
        exit();
    }
    else if($action == UPDATE_ACTION){
        $id = (isset($_GET['id'])) ? sanitize($conn, $_GET['id']): 0;
        $result = mysqli_query($conn, "SELECT * FROM division_master WHERE id='$id' ");
        while($myrow = mysqli_fetch_assoc($result))
        {
            $division = $myrow["division"];
        }
    }
    
    if(isset($_POST['submit']))
    {
        $id = array_key_exists('id', $_POST) ? sanitize($conn, $_POST['id']) : '';
        $division = array_key_exists('division', $_POST) ? sanitize($conn, $_POST['division']) : '';
        $action = sanitize($conn, $_POST['submit']);

        if(empty($division)){
            $_SESSION['error_msg'] = "Please enter division name.";            
        }
        else{
            if($action == ADD_ACTION){
                //check duplication
                $dup = "select * from division_master where division='$division'";
                $dup_res = mysqli_query($conn, $dup) or die(mysqli_error($conn));
                if(mysqli_num_rows($dup_res)==1)
                {                
                    $_SESSION['error_msg'] = "Division name is already available in database.";                 
                }
                else
                {
                    //run the query which adds the data gathered from the form into the database
                    mysqli_query($conn, "INSERT INTO division_master (division) VALUES ('$division')");                
                    $_SESSION['success_msg'] = "Division is added Successfully!";                
                    header( "refresh:0;url=division.php" );
                    exit();
                }
            }
            else if($action == UPDATE_ACTION){
                //check duplication
                $dup = "select * from division_master where division='$division' and id != $id";
                $dup_res = mysqli_query($conn, $dup) or die(mysqli_error($conn));
                if(mysqli_num_rows($dup_res)==1)
                {
                    $_SESSION['error_msg'] = "Division name is already available in database.";
                }
                else
                {                                                                
                    $result = mysqli_query($conn, "UPDATE division_master SET division='$division' WHERE id='$id'");
                    $_SESSION['success_msg'] = "Division is updated successfully!";            
                    header( "refresh:0;url=division.php" );
                    exit();
                }
            }
        }
    }
           
    ShowSessionMsg();
    include_once 'division_form.php';
    include_once '../common_html_php_code/footer.php';
?>
<script language="javascript" type="text/javascript">
    function chkForm()
    {
        if ( $("#id_division_name").val().length < 1 )
        {
            alert("Enter division name");	
            $("#id_division_name").focus();		
            return false;
        }            
    }
</script>         