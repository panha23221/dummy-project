<h1 class="h2"><?php echo ($action == UPDATE_ACTION) ? UPDATE_ACTION_TEXT : ADD_ACTION_TEXT ?> Semester</h1>  
<form method="post" class="form" action="<?php echo $_SERVER['REQUEST_URI'] ?>" onsubmit="return chkForm();">
    <?php if ($action == UPDATE_ACTION){ ?>
        <input type="hidden" name="sem_id" value="<?php echo $sem_id?>" />
    <?php } ?>
    <div class="form-group">
        <label class="control-label col-sm-2">Semester Name</label>
        <div class="col-sm-4">
            <input type="text" class="form-control" id="id_sem_name" name="sem_name" placeholder="Enter semester name" value="<?php echo $sem_name ?>"/>
        </div>
    </div>
    <div class="form-group">
        <div class="col-sm-offset-2 col-sm-4">
            <button type="submit" class="btn btn-default" name="submit" id="id_submit" value="<?php echo $action ?>"><?php echo ($action == UPDATE_ACTION) ? UPDATE_ACTION_TEXT : ADD_ACTION_TEXT ?></button>
            <a href='semester.php' class="btn btn-danger">Back</a>
        </div>
    </div>
</form>