<?php 
    include_once '../common_html_php_code/header.php';

    function number_pad($number,$n) {
        return str_pad((int) $number,$n,"0",STR_PAD_LEFT);
    }
    if(isset($_POST['submit']))
    {
        $year = sanitize($conn, $_POST['year']);
        $alphabet = sanitize($conn, $_POST['alphabet']);
        $start_range = sanitize($conn, $_POST['start_range']);
        $end_range = sanitize($conn, $_POST['end_range']);
        $n = 3;//strlen($end_range);

        //check duplication			
        $new = array();
        $flag = 0;
        $error_msg = '';
        for($i=$start_range; $i<= $end_range; $i++)
        {	  
            $std_id = $year.$alphabet.number_pad($i,$n);

            $dup="select * from student_master where roll_no = '".$std_id."'";		
            $dup_res=mysqli_query($conn, $dup) or die(mysqli_error($conn));

            if(mysqli_num_rows($dup_res)==1)
            {
                //duplicate roll no will not be created again
                $error_msg .= $std_id.', ';
            }
            else
            {			  			
                $value = array($std_id, md5($std_id), $std_id, '', '');
                $new[] = "'".implode("', '", $value)."'";
                $flag = 1;
            }
        }     
        if($flag == 1)
        { 
            $query = "(".implode("), (", $new).")";	 			
            mysqli_query($conn, "INSERT INTO student_master (roll_no, passwd, first_name, last_name, email_id) VALUES ".$query.";") or die(mysqli_error($conn));
        }
        //print success message.
        echo "<b>Student ID are created successfully!</b>";
        if($error_msg)
        {
            $error_msg = rtrim($error_msg, ", ");
            echo "<br><b>But following ID are not created because they are already exits in table $error_msg</b>";
        }
        //echo "<meta http-equiv=Refresh content=1;url=faculty.php>";
        // echo "<!--<meta http-equiv=Refresh content=4;url=index.php>-->";	

    }//end of if($submit).

?>
                    
<form name="std_id_form" action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post" enctype="multipart/form-data" onsubmit="return chkForm();">
    <table width="480px" align="center">
        <tr>
            <td>Enter Year</td><td>
                <select name="year" id="id_year">
                <?php 
                    for($i = 2010 ; $i <= date('Y'); $i++){
                        $y = substr($i, -2);			   
                        echo "<option value='$y'>$y</option>";
                    }
                ?>
                </select>
            </td>
        </tr>
        <tr>
            <td>Select Alphabet</td>
            <td>
                <select name="alphabet">
                <?php
                    foreach (range('A', 'Z') as $char) {
                        echo "<option value='$char'>$char</option>"; //$char . "\n";
                    }
                ?>			
                </select>
            </td>
        </tr>
        <tr>
            <td>ID Start Range</td><td><input name="start_range" value="" id="id_start_range" onkeypress="return isNumberOnly(event);" /></td>
        </tr>
        <tr>
            <td>ID End Range</td><td><input name="end_range" value="" id="id_end_range" onkeypress="return isNumberOnly(event);" /></td>
        </tr>
        <tr>
            <td colspan="2" ><input class="button" type="submit" name="submit" value="Submit" id="id_submit" /></td>
        </tr>	
    </table>
</form>
<?php
    include_once '../common_html_php_code/footer.php';
?>
<script language="javascript" type="text/javascript">
            
    function chkForm(form)
    {
        var RefForm = document.std_id_form;

        if (RefForm.start_range.value == '')
        {
            alert("Enter start range");			
            RefForm.start_range.focus();
            return false;
        }
        if (RefForm.end_range.value == '')
        {
            alert("Enter end range");
            RefForm.end_range.focus();			
            return false;
        }

        if (RefForm.start_range.value != '' && RefForm.end_range.value != '' && RefForm.start_range.value > RefForm.end_range.value)
        {
            alert("start no should be lower than end no");			
            RefForm.start_range.focus();
            return false;
        }

        return true;				
    }
</script>