<?php
    include_once '../common_html_php_code/header.php';
    include("xls.php");

    function common_get_value_from_post($POST, $field_name){
        if(!array_key_exists($field_name, $POST)){return 0;}                
        return implode(",", array_map('intval', $POST[$field_name]));
    }

    $date_period_str = "";
    if (isset($_POST['Submit']) || isset($_POST['xls_file'])) {
        $query_string    = " ";

        $college_name    = common_get_value_from_post($_POST, 'college_name');
        $branch_name     = common_get_value_from_post($_POST, 'branch_name');
        $batch_name      = common_get_value_from_post($_POST, 'batch_name');
        $sem_name        = common_get_value_from_post($_POST, 'sem_name');
        $division_name   = common_get_value_from_post($_POST, 'division_name');
        $faculty_name    = common_get_value_from_post($_POST, 'faculty_name');             
        $subject_name    = common_get_value_from_post($_POST, 'subject_name');

        $sql_date_period = " ";

        if (isset($college_name) && $college_name > 0) {
            $temp_string = " college_id in (" . $college_name . ") ";
            if (isset($query_string) && !empty($query_string)) {
                $query_string .= "$temp_string and";
            } else {
                $query_string = $temp_string;
            }
        }

        if (isset($batch_name) && $batch_name > 0) {
            $temp_string = " batch_id in (" . $batch_name . ") ";
            if (isset($query_string) && !empty($query_string)) {
                $query_string .= "$temp_string and";
            } else {
                $query_string = $temp_string;
            }
        }
        if (isset($branch_name) && $branch_name > 0) {
            $temp_string = " b_id in (" . $branch_name . ") ";
            if (isset($query_string) && !empty($query_string)) {
                $query_string .= " $temp_string and ";
            } else {
                $query_string = $temp_string;
            }
        }
        if (isset($sem_name) && $sem_name > 0) {
            $temp_string = " sem_id in (" . $sem_name . ") ";
            if (isset($query_string) && !empty($query_string)) {
                $query_string .= "$temp_string and";
            } else {
                $query_string = $temp_string;
            }
        }
        if (isset($division_name) && $division_name > 0) {
            $temp_string = " division_id in (" . $division_name . ") ";
            if (isset($query_string) && !empty($query_string)) {
                $query_string .= "$temp_string and";
            } else {
                $query_string = $temp_string;
            }
        }
        /*if(isset($_POST['feedback_no']))
        {
        $query_string.=" feedback_no='".$_POST['feedback_no']."' and";
        $feedback_no=$_POST['feedback_no'];
        }*/
        if (isset($faculty_name) && $faculty_name > 0) {
            $temp_string = " f_id in (" . $faculty_name . ") ";
            if (isset($query_string) && !empty($query_string)) {
                $query_string .= "$temp_string and";
            } else {
                $query_string = $temp_string;
            }
        }
        if (isset($subject_name) && $subject_name > 0) {
            $temp_string = " sub_id in (" . $subject_name . ") ";
            if (isset($query_string) && !empty($query_string)) {
                $query_string .= "$temp_string ";
            } else {
                $query_string = $temp_string;
            }
        }

        $slq_search = "select * from feedback_master where (" . $query_string . ")";
        //echo $slq_search;
        $res_search = mysqli_query($conn, $slq_search) or die(mysqli_error($conn));

        $sql_date_period = "select max(feed_date) as to_date, min(feed_date) as from_date from feedback_master where (" . $query_string . ") group by feed_date";
        $res_date_period = mysqli_query($conn, $sql_date_period) or die(mysqli_error($conn));
        while ($row = mysqli_fetch_array($res_date_period)) {
            $date_period_str = "[ " . date("d-m-Y", strtotime($row["from_date"])) . " - " . date("d-m-Y", strtotime($row["to_date"])) . " ]";
        }

        if ($_POST['query_set'] == '1') {
            $file_name = write_xls($conn, $slq_search, $date_period_str, $subject_name);
        }
    } else {
        //$slq_search="select * from feedback_master order by feed_date asc";
        $slq_search = 'select * from feedback_master where feed_id=0';
        //echo $sql_search;
        $res_search = mysqli_query($conn, $slq_search) or die(mysqli_error($conn));
    }
?>
    <form name="feedback_form" id="id_feedback_form" action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post" enctype="multipart/form-data">
        <input type="hidden" name="feedback_no" value="1"/>
        <div class="container-fluid">
            <div class="row ">
                
                <div class="col-2">
                    <label><strong>College</strong></label>
                    <?php
                        $sel_college = "select c_id, c_name from college_master";
                        $res_college = mysqli_query($conn, $sel_college) or die(mysqli_error($conn));

                        while ($college_combo = mysqli_fetch_array($res_college)) {
                            $college_array[] = array('id' => $college_combo['c_id'],
                                                     'text'=> $college_combo['c_name']);
                        }
                        if (isset($college_name)) {
                            $default = $college_name;
                        } else {
                            $default = '';
                        }                                                    
                        echo tep_draw_pull_down_menu_select_multiple(
                            'college_name[ ]', $college_array, $default, ' id="id_college_name" multiple size="5"  class="form-control" ');
                    ?>
                </div>
                <div class="col-3">
                    <label><strong>Branch</strong></label>
                    <div id="id_branch_dropdown_div"></div>
                </div>
                
                <div class="col-2">
                    <label><strong>Batch</strong></label>
                    <?php
                        $sel_batch = "select batch_id, batch_name from batch_master";
                        $res_batch = mysqli_query($conn, $sel_batch) or die(mysqli_error($conn));

                        while ($batch_combo = mysqli_fetch_array($res_batch)) {
                            $batch_array[] = array('id' => $batch_combo['batch_id'],
                                                   'text' => $batch_combo['batch_name']);
                        }
                        if (isset($batch_name)) {
                            $default = $batch_name;
                        } else {
                            $default = '';
                        }

                        echo tep_draw_pull_down_menu_select_multiple(
                            'batch_name[ ]', $batch_array, $default, ' id="id_batch_name" multiple size="5" class="form-control" ');
                    ?>
                </div>

                <div class="col-2">
                    <label><strong>Semester</strong></label>
                    <?php
                        $sel_sem = "select sem_id, sem_name from semester_master";
                        $res_sem = mysqli_query($conn, $sel_sem) or die(mysqli_error($conn));

                        while ($sem_combo = mysqli_fetch_array($res_sem)) {
                            $sem_array[] = array('id' => $sem_combo['sem_id'],
                                                 'text' => $sem_combo['sem_name']);
                        }
                        if (isset($sem_name)) {
                            $default = $sem_name;
                        } else {
                            $default = !empty($_SESSION['student_sem_id_val']) ? $_SESSION['student_sem_id_val'] : '';
                        }

                        echo tep_draw_pull_down_menu_select_multiple(
                            'sem_name[ ]', $sem_array, $default, ' id="id_sem_name" multiple size="5" class="form-control" ');
                    ?>
                </div>
                
                <div class="col-2">
                    <label><strong>Division</strong></label>
                    <?php
                        $sel_division = "select id, division from division_master";
                        $res_division = mysqli_query($conn, $sel_division) or die(mysqli_error($conn));

                        while ($division_combo = mysqli_fetch_array($res_division)) {
                            $division_array[] = array('id' => $division_combo['id'],
                                                      'text' => $division_combo['division']);
                        }
                        if (isset($division_name)) {
                            $default = $division_name;
                        } else {
                            $default = !empty($_SESSION['student_division_id_val']) ? $_SESSION['student_division_id_val'] : '';
                        }

                        echo tep_draw_pull_down_menu_select_multiple(
                            'division_name[ ]', $division_array, $default, ' id="id_division_name" multiple size="5" class="form-control" ');
                    ?>
                </div>
            </div>
            <div class="row"><div class="col-12">&nbsp;</div></div>
            <div class="row">
                <div class="col-5">
                    <label><strong>Faculty</strong></label>
                    <div id="id_faculty_dropdown_div"></div>
                </div>
                <div class="col-6">
                    <label><strong>Subject</strong></label>
                    <div id="id_subject_dropdown_div"></div>
                </div>
            </div>
            <div class="row"><div class="col-12">&nbsp;</div></div>
            <div class="row">
                <div class="col-12">
                    <input class="btn btn-blue" type="submit" id="id_submit" name="Submit" value="Submit" />
                    <input class="btn btn-elegant" type="button" value="Reset" onclick="location.href='<?php echo $_SERVER['PHP_SELF'] ?>'" />

                    <script language="javascript" type="text/javascript">

                        function call_overall_graph(encoded_sql_query, encoded_sql_date_period, encode_sql_subject_ids)
                        {
                            url = "graph_img_n_data.php?str=" + encoded_sql_query + "&date_period=" + encoded_sql_date_period + "&sub_id="+encode_sql_subject_ids;
                            var win = window.open(url, '_blank');
                            win.focus();
                        }
                        function call_que_rating_student_graph(encoded_sql_search_para, encoded_sql_date_period, encode_sql_subject_ids)
                        {
                            url = "graph_rating_student_count.php?str=" + encoded_sql_search_para + "&date_period="+encoded_sql_date_period + "&sub_id="+encode_sql_subject_ids;
                            var win = window.open(url, '_blank');
                            win.focus();
                        }
                        function call_rating_student_graph(encoded_sql_query)
                        {
                            url = "graph_ovarall_rating_student_count.php?str=" + encoded_sql_query;
                            var win = window.open(url, '_blank');
                            win.focus();
                        }
                    </script>

                    <?php
                        if (isset($_POST['Submit']) && mysqli_num_rows($res_search) > 0) {
                            $encoded_sql_query       = base64_encode($slq_search);
                            $encoded_sql_search_para = base64_encode($query_string);
                            $encoded_sql_date_period = base64_encode($sql_date_period);
                            $encode_sql_subject_ids  = base64_encode($subject_name);
                    ?>
                            <input class="btn btn-dark-green" type="button" id="id_overall_graph_button" name="overall_graph_button" value="Avg. report" onclick="javascript:call_overall_graph('<?php echo $encoded_sql_query ?>', '<?php echo $encoded_sql_date_period ?>', '<?php echo $encode_sql_subject_ids ?>');"/>
                            <input class="btn btn-deep-orange" type="button" id="id_que_rating_student" name="que_rating_student" value="Overall Rating" onclick="javascript:call_que_rating_student_graph('<?php echo $encoded_sql_search_para ?>', '<?php echo $encoded_sql_date_period ?>', '<?php echo $encode_sql_subject_ids ?>');"/>
                    <?php
                        }
                    ?>                                                
                    <input type="hidden" name="query_set" value="" />

                    <?php
                        if (isset($_POST['Submit']) && mysqli_num_rows($res_search) > 0) {
                            echo '<input type="submit" name="xls_file" class="btn btn-deep-purple" value="Generate xls file" onclick="javascript: create_xls();" />';
                        }
                        if (isset($_REQUEST['query_set'])) {
                            if ($_REQUEST['query_set'] == '1') {
                                echo '<a href="excel_report/' . $file_name . '" target="_blank" class="btn btn-success"><i class="fas fa-download fa-lg"></i> Download excel report</a>';
                            }
                        } else {
                            $file_name = '';
                        }
                    ?>
                </div>
            </div>
        </div>
    </form>
    
    <?php if (mysqli_num_rows($res_search) > 0) {?>
        <div class="row">
            <div class="col-6"><strong>Feedback duration</strong> : <?php echo $date_period_str; ?></div>
            <div class="col-6" align="right"><strong>Number of Records</strong> : <?php echo mysqli_num_rows($res_search); ?></div>
        </div>
        
    <?php } ?>
    <div class="table-responsive">
        <table class="table table-striped table-sm" >
            <thead class="thead-dark">
                <tr>
                    <th><!--Roll No--></th>
                    <th><strong>Ans1</strong></th>
                    <th><strong>Ans2</strong></th>
                    <th><strong>Ans3</strong></th>
                    <th><strong>Ans4</strong></th>
                    <th><strong>Ans5</strong></th>
                    <th><strong>Ans6</strong></th>
                    <th><strong>Ans7</strong></th>
                    <th><strong>Ans8</strong></th>
                    <th><strong>Ans9</strong></th>
                    <th><strong>Ans10</strong></th>
                    <!--<th class="rounded-q3" scope="col"><div align="center">Ans11</div></th>
                    <th class="rounded-q3" scope="col"><div align="center">Ans12</div></th>
                    <th class="rounded-q3" scope="col"><div align="center">Ans13</div></th>
                    <th class="rounded-q3" scope="col"><div align="center">Ans14</div></th>
                    <th class="rounded-q3" scope="col"><div align="center">Ans15</div></th>
                    <th scope="col" class="rounded-q4" align="center">Edit / Delete</th>-->
                    <th><strong>Remark</strong></th>
                </tr>
            </thead>

            <?php
                function cal_percentage($total_ans, $r_id)
                {
                    $percent = ($total_ans / ($r_id * 10)) * 100;
                    return number_format((float) $percent, 2, '.', '');
                }

                if (mysqli_num_rows($res_search) != 0) {
                    $total_ans1  = 0;
                    $total_ans2  = 0;
                    $total_ans3  = 0;
                    $total_ans4  = 0;
                    $total_ans5  = 0;
                    $total_ans6  = 0;
                    $total_ans7  = 0;
                    $total_ans8  = 0;
                    $total_ans9  = 0;
                    $total_ans10 = 0;
                    //$total_ans11=0;
                    //$total_ans12=0;
                    //$total_ans13=0;
                    //$total_ans14=0;
                    //$total_ans15=0;
                    $i = 0;
                    while ($myrow = mysqli_fetch_array($res_search)) {
                        //now print the results:
                        echo '<tr>';
                        echo "<td>&nbsp;</td>"; // $myrow['roll_no']
                        $i++;
                        echo "<td>" . $myrow['ans1'] . "</td>";
                        echo "<td>" . $myrow['ans2'] . "</td>";
                        echo "<td>" . $myrow['ans3'] . "</td>";
                        echo "<td>" . $myrow['ans4'] . "</td>";
                        echo "<td>" . $myrow['ans5'] . "</td>";
                        echo "<td>" . $myrow['ans6'] . "</td>";
                        echo "<td>" . $myrow['ans7'] . "</td>";
                        echo "<td>" . $myrow['ans8'] . "</td>";
                        echo "<td>" . $myrow['ans9'] . "</td>";
                        echo "<td>" . $myrow['ans10'] . "</td>";
                        //echo "<td>".$myrow['ans11']."</td>";
                        //echo "<td>".$myrow['ans12']."</td>";
                        //echo "<td>".$myrow['ans13']."</td>";
                        //echo "<td>".$myrow['ans14']."</td>";
                        //echo "<td>".$myrow['ans15']."</td>";
                        echo "<td>" . ($myrow['remark'] != '' ? '<a href="javascript: void(0)"
                            onclick="window.open(\'popup.php?feed_id=' . $myrow['feed_id'] . '\',\'windowname1\',\'width=200, height=77\');return false;" title="Remark"><i class="fas fa-marker fa-lg"></i></a>' : '&nbsp;') . "&nbsp;</td>";

                        echo '</tr>';

                        $total_ans1  = $total_ans1 + $myrow['ans1'];
                        $total_ans2  = $total_ans2 + $myrow['ans2'];
                        $total_ans3  = $total_ans3 + $myrow['ans3'];
                        $total_ans4  = $total_ans4 + $myrow['ans4'];
                        $total_ans5  = $total_ans5 + $myrow['ans5'];
                        $total_ans6  = $total_ans6 + $myrow['ans6'];
                        $total_ans7  = $total_ans7 + $myrow['ans7'];
                        $total_ans8  = $total_ans8 + $myrow['ans8'];
                        $total_ans9  = $total_ans9 + $myrow['ans9'];
                        $total_ans10 = $total_ans10 + $myrow['ans10'];
                        //$total_ans11 = $total_ans11 + $myrow['ans11'];
                        //$total_ans12 = $total_ans12 + $myrow['ans12'];
                        //$total_ans13 = $total_ans13 + $myrow['ans13'];
                        //$total_ans14 = $total_ans14 + $myrow['ans14'];
                        //$total_ans15 = $total_ans15 + $myrow['ans15'];

                        //echo "<br><a href=\"read_more.php?newsid=$myrow[newsid]\">Read More...</a>
                        //  || <a href=\"edit_news.php?newsid=$myrow[newsid]\">Edit</a>
                        //   || <a href=\"delete_news.php?newsid=$myrow[newsid]\">Delete</a><br><hr>";
                    } //end of loop

                    //echo '<tr><th scope="col" class="rounded-q1" colspan=17>Total</th></tr>';
                    echo '<tr class="thead-light">';
                    echo '<th><strong>Total</strong></th>';
                    echo '<th>' . $total_ans1 . '</th>';
                    echo '<th>' . $total_ans2 . '</th>';
                    echo '<th>' . $total_ans3 . '</th>';
                    echo '<th>' . $total_ans4 . '</th>';
                    echo '<th>' . $total_ans5 . '</th>';
                    echo '<th>' . $total_ans6 . '</th>';
                    echo '<th>' . $total_ans7 . '</th>';
                    echo '<th>' . $total_ans8 . '</th>';
                    echo '<th>' . $total_ans9 . '</th>';
                    echo '<th>' . $total_ans10 . '</th>';
                    //echo '<th>'.$total_ans11.'</th>';
                    //echo '<th>'.$total_ans12.'</th>';
                    //echo '<th>'.$total_ans13.'</th>';
                    //echo '<th>'.$total_ans14.'</th>';
                    //echo '<th>'.$total_ans15.'</th>';
                    echo '<th>&nbsp;</th>';
                    echo '</tr>';

                    //echo '<tr><th scope="col" class="rounded-q1" colspan=16>Percentage</th></tr>';
                    echo '<tr class="thead-dark">';
                    echo '<th><strong>per(%)</strong></th>';
                    echo '<th>' . cal_percentage($total_ans1, $i) . '%</th>';
                    echo '<th>' . cal_percentage($total_ans2, $i) . '%</th>';
                    echo '<th>' . cal_percentage($total_ans3, $i) . '%</th>';
                    echo '<th>' . cal_percentage($total_ans4, $i) . '%</th>';
                    echo '<th>' . cal_percentage($total_ans5, $i) . '%</th>';
                    echo '<th>' . cal_percentage($total_ans6, $i) . '%</th>';
                    echo '<th>' . cal_percentage($total_ans7, $i) . '%</th>';
                    echo '<th>' . cal_percentage($total_ans8, $i) . '%</th>';
                    echo '<th>' . cal_percentage($total_ans9, $i) . '%</th>';
                    echo '<th>' . cal_percentage($total_ans10, $i) . '%</th>';
                    //echo '<th>'.cal_percentage($total_ans11, $i).'%</th>';
                    //echo '<th>'.cal_percentage($total_ans12, $i).'%</th>';
                    //echo '<th>'.cal_percentage($total_ans13, $i).'%</th>';
                    //echo '<th>'.cal_percentage($total_ans14, $i).'%</th>';
                    //echo '<th>'.cal_percentage($total_ans15, $i).'%</th>';
                    echo '<th>&nbsp;</td>';
                    echo '</tr>';
                } else {
                    echo '<tr>';
                    echo "<td colspan=12 align=center><strong>No Record Found!</strong></td></tr>";
                }
            ?>
        </table>
    </div>
<?php         
    include_once '../common_html_php_code/footer.php';
?>
<script language="javascript" type="text/javascript">
    function branch_change(){
        get_all_faculty_list(undefined, 1);
        return false;
    }
    
    $( "#id_college_name,#id_batch_name,#id_sem_name,#id_division_name" ).change(function(e) { 
        
        if(e.target.id == 'id_college_name'){ 
            get_branch_list(undefined, 1);
        };
        get_all_faculty_list(undefined, 1);
        return false;
    });
    
    $("#id_branch_name").change(function(e) {
        get_all_faculty_list(undefined, 1);
        return false;
    });
    
    $("#id_submit").click(function (){

        if ( $("#id_college_name").val() <= 0 )
        {
            alert("Select College");
            $("#id_college_name").focus();
            return false;
        }
        
        if ( $("#id_faculty_name").val() <= 0  )
        {
            alert("Select Faculty Name.");
            $("#id_faculty_name").focus();
            return false;
        }
        if ( $("#id_subject_name").val() <= 0 )
        {
            alert("Select Subject");
            $("#id_subject_name").focus();
            return false;
        }
        $("#id_feedback_form").submit();
    });

    function create_xls()
    {
        document.feedback_form.query_set.value='1';
        return true;
    }
</script>
<?php
if (isset($_POST['Submit']) && isset($faculty_name) || isset($_POST['xls_file'])) {
?>
    <script type='text/javascript'>
        get_all_faculty_list('<?php echo $faculty_name ?>', 1);
        get_all_subjects('<?php echo $subject_name ?>', '<?php echo $faculty_name ?>', '<?php echo $branch_name ?>', 1);
        get_branch_list('<?php echo $branch_name ?>', 1);
    </script>
<?php

}

function write_xls($conn, $sql, $date_period_str, $subject_name)
{
    $excel = new ExcelWriter('excel_report/' . date('m_d_Y_s') . '_feedback_report.xls');
    $file_name = date('m_d_Y_s') . '_feedback_report.xls';

    if ($excel == false) {
        echo $excel->error;
    }
    
    $sub_name = str_replace('\\', '', $subject_name);
    //echo $sub_name;
    $sql_subj_details = "SELECT cm.c_name, sm.sub_id, sm.sub_name, bm.batch_name, brm.b_name, sem.sem_name, dm.division, fm.f_name, fm.l_name ".
        "FROM subject_master as sm ".
        "INNER JOIN faculty_master fm on fm.f_id = sm.f_id ".
        "INNER JOIN batch_master bm on bm.batch_id = sm.batch_id ".
        "INNER JOIN branch_master brm on brm.b_id = sm.branch_id ".
        "INNER JOIN semester_master sem on sem.sem_id = sm.sem_id ".
        "INNER JOIN division_master dm on dm.id = sm.division_id ". 
        "INNER JOIN college_master cm on cm.c_id = fm.c_id ". 
        "WHERE sub_id in ($sub_name) ";
    //echo $sql_subj_details;
    $res_subj_details = mysqli_query($conn, $sql_subj_details) or die("error in query");
    
    $myArr = array("Faculty", "Subject", "College", "Branch", "Batch", "Semester", "Division");
    $excel->writeLine($myArr);
    
     
    while ($row = mysqli_fetch_array($res_subj_details)) {
        $myArr = array($row["f_name"]." ".$row["l_name"], $row["sub_name"], $row["c_name"], $row["b_name"], $row["batch_name"], $row["sem_name"], $row["division"]);
        $excel->writeLine($myArr);
    }
    
    $myArr = array("", "", "", "", "", "");
    $excel->writeLine($myArr);
    
    $myArr = array("Duration", "$date_period_str", "", "", "", "");
    $excel->writeLine($myArr);
       
    $sql   = str_replace('\\', '', $sql);
    $result1 = mysqli_query($conn, $sql) or die(mysqli_error($conn));
    $arr1    = mysqli_fetch_array($result1);

    if (mysqli_num_rows($result1) != 0) {

        $myArr = array("", "", "", "", "", "");
        $excel->writeLine($myArr);

        $myArr = array("Roll no", "Ans1", "Ans2", "Ans3", "Ans4", "Ans5", "Ans6", "Ans7", "Ans8", "Ans9", "Ans10", "Remark");
        //, "Ans11", "Ans12", "Ans13", "Ans14", "Ans15",
        $excel->writeLine($myArr);

        $result    = mysqli_query($conn, $sql) or die(mysqli_error($conn));
        $total_ids = "0";

        $r_id = 0;

        $total_ans1  = 0;
        $total_ans2  = 0;
        $total_ans3  = 0;
        $total_ans4  = 0;
        $total_ans5  = 0;
        $total_ans6  = 0;
        $total_ans7  = 0;
        $total_ans8  = 0;
        $total_ans9  = 0;
        $total_ans10 = 0;
        /*$total_ans11 = 0;
        $total_ans12 = 0;
        $total_ans13 = 0;
        $total_ans14 = 0;
        $total_ans15 = 0;*/

        while ($arr = mysqli_fetch_array($result)) {
            /*if($arr['remark']!=NULL)
            {
            $myArr=array(strtolower($arr['remark']));
            $excel->writeLine($myArr);
            $r_id++;
            }*/

            $myArr = array($arr['roll_no'], $arr['ans1'], $arr['ans2'], $arr['ans3'], $arr['ans4'], $arr['ans5'], $arr['ans6'], $arr['ans7'], $arr['ans8'], $arr['ans9'], $arr['ans10'], $arr['remark']);
            //, $arr['ans11'], $arr['ans12'], $arr['ans13'], $arr['ans14'], $arr['ans15'],
            $excel->writeLine($myArr);
            $r_id++;

            $total_ans1  = $total_ans1 + $arr['ans1'];
            $total_ans2  = $total_ans2 + $arr['ans2'];
            $total_ans3  = $total_ans3 + $arr['ans3'];
            $total_ans4  = $total_ans4 + $arr['ans4'];
            $total_ans5  = $total_ans5 + $arr['ans5'];
            $total_ans6  = $total_ans6 + $arr['ans6'];
            $total_ans7  = $total_ans7 + $arr['ans7'];
            $total_ans8  = $total_ans8 + $arr['ans8'];
            $total_ans9  = $total_ans9 + $arr['ans9'];
            $total_ans10 = $total_ans10 + $arr['ans10'];
            /*$total_ans11 = $total_ans11 + $arr['ans11'];
            $total_ans12 = $total_ans12 + $arr['ans12'];
            $total_ans13 = $total_ans13 + $arr['ans13'];
            $total_ans14 = $total_ans14 + $arr['ans14'];
            $total_ans15 = $total_ans15 + $arr['ans15'];*/
        }

        $myArr = array("", "", "", "", "", "");
        $excel->writeLine($myArr);

        //$myArr=array("Total",);
        //$excel->writeLine($myArr);

        $myArr = array("Total", $total_ans1, $total_ans2, $total_ans3, $total_ans4, $total_ans5, $total_ans6, $total_ans7, $total_ans8, $total_ans9, $total_ans10);
        //, $total_ans11, $total_ans12, $total_ans13, $total_ans14, $total_ans15
        $excel->writeLine($myArr);

        $myArr = array("", "", "", "", "", "");
        $excel->writeLine($myArr);

        //$myArr=array("Percentage",);
        //$excel->writeLine($myArr);

        //$percent_1 = ("%.2f", $percent_1);
        $percent_1  = cal_percentage($total_ans1, $r_id);
        $percent_2  = cal_percentage($total_ans2, $r_id);
        $percent_3  = cal_percentage($total_ans3, $r_id);
        $percent_4  = cal_percentage($total_ans4, $r_id);
        $percent_5  = cal_percentage($total_ans5, $r_id);
        $percent_6  = cal_percentage($total_ans6, $r_id);
        $percent_7  = cal_percentage($total_ans7, $r_id);
        $percent_8  = cal_percentage($total_ans8, $r_id);
        $percent_9  = cal_percentage($total_ans9, $r_id);
        $percent_10 = cal_percentage($total_ans10, $r_id);
        /*$percent_11 = cal_percentage($total_ans11, $r_id);
        $percent_12 = cal_percentage($total_ans12, $r_id);
        $percent_13 = cal_percentage($total_ans13, $r_id);
        $percent_14 = cal_percentage($total_ans14, $r_id);
        $percent_15 = cal_percentage($total_ans15, $r_id);*/

        $myArr = array("Per(%)", $percent_1 . "%", $percent_2 . "%", $percent_3 . "%", $percent_4 . "%", $percent_5 . "%", $percent_6 . "%", $percent_7 . "%", $percent_8 . "%", $percent_9 . "%", $percent_10 . "%");
        //, $percent_11 . "%", $percent_12 . "%", $percent_13 . "%", $percent_14 . "%", $percent_15 . "%"
        $excel->writeLine($myArr);
        //$myArr=array((string)$total_ans1,(string)$total_ans2,(string)$total_ans3,(string)$total_ans4,(string)$total_ans5,(string)$total_ans6,(string)$total_ans7,(string)$total_ans8,(string)$total_ans9,(string)$total_ans10,(string)$total_ans11,(string)$total_ans12,(string)$total_ans13,(string)$total_ans14,(string)$total_ans15,$arr['remark']);
        //$excel->writeLine($myArr);

        $excel->close();
        return $file_name;
    } else {
        echo '<p align=center>No Record Found!.</p>';
    }
}

?>
