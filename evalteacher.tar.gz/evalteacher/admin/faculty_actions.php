<?php 
    include_once '../common_html_php_code/header.php';
    $action = (int)((isset($_GET['action'])) ? sanitize($conn, $_GET['action']): ADD_ACTION);
    $f_name = '';
    $l_name = '';
    $c_id = '';
    
    if($action == DELETE_ACTION){    
        delete_record($_GET, $conn, array("subject_master", "faculty_master"), "f_id", "faculty.php");
        exit();
        
    }
    else if($action == UPDATE_ACTION){
        $f_id = (isset($_GET['id'])) ? sanitize($conn, $_GET['id']): 0;
        $result = mysqli_query($conn, "SELECT * FROM  faculty_master WHERE f_id='$f_id' ");
        while($myrow = mysqli_fetch_assoc($result))
        {
            $f_name = $myrow["f_name"];
            $l_name = $myrow["l_name"];
            $c_id = $myrow["c_id"];
        }
    }
    
    
    if(isset($_POST['submit']))
    {
        $f_id = array_key_exists('f_id', $_POST) ? sanitize($conn, $_POST['f_id']) : '';
        $f_name = array_key_exists('f_name', $_POST) ? sanitize($conn, $_POST['f_name']) : '';
        $l_name = array_key_exists('l_name', $_POST) ? sanitize($conn, $_POST['l_name']) : '';
        $c_id = array_key_exists('college_id', $_POST) ? sanitize($conn, $_POST['college_id']) : '';

        if(empty($f_name)){
            $_SESSION['error_msg'] = "Please enter first name.";            
        }
        else if(empty($l_name)){
            $_SESSION['error_msg'] = "Please enter last name.";            
        }
        else if(empty($c_id) || $c_id <= 0 || $c_id == null)
        {  
            $_SESSION['error_msg'] = "Error: Select college where faculty belong to.";             
        }
        else{
            if($action == ADD_ACTION){
                //check duplication
                $dup="select * from faculty_master  where f_name='".$f_name."' and l_name='".$l_name."' and c_id = '".$c_id."'";
                $dup_res=mysqli_query($conn, $dup) or die(mysqli_error($conn));
                if(mysqli_num_rows($dup_res)==1)
                {
                    $_SESSION['error_msg'] = "Faculty name is already available in college."; 
                }
                else
                {
                    //run the query which adds the data gathered from the form into the database
                    mysqli_query($conn, "INSERT INTO faculty_master (f_name, l_name, c_id) VALUES ('$f_name', '$l_name', '$c_id')");
                    $_SESSION['success_msg'] = "Faculty is added Successfully!";                
                    header( "refresh:0;url=faculty.php" );
                    exit();                               
                }
            }
            if($action == UPDATE_ACTION){
                $dup="select * from  faculty_master where f_name='".$f_name."' and l_name='".$l_name."' and c_id='".$c_id."' and f_id!=".$f_id;
                $dup_res=mysqli_query($conn, $dup) or die(mysqli_error($conn));
                if(mysqli_num_rows($dup_res)==1)
                {
                    $_SESSION['error_msg'] = "Faculty name is already available in college.";                              
                }
                else
                {                           
                    $sql = "UPDATE  faculty_master  SET f_name='".$f_name."', l_name='".$l_name."', c_id = '".$c_id."' WHERE f_id='$f_id'";
                    mysqli_query($conn, $sql);
                    $_SESSION['success_msg'] = "Faculty detail is updated successfully!";            
                    header( "refresh:0;url=faculty.php" );
                    exit();
                }
            }
        }
    }
    
    ShowSessionMsg();
    include_once 'faculty_form.php';
    include_once '../common_html_php_code/footer.php';
?>            
                
<script language="javascript" type="text/javascript">    
    function chkForm(form)
    {
        if ( $("#id_f_name").val().length < 1 )
        {
            alert("Enter frist name");	
            $("#id_f_name").focus();		
            return false;
        }
        if ( $("#id_l_name").val().length < 1 )
        {
            alert("Enter last name");	
            $("#id_l_name").focus();		
            return false;
        }
        if ($("#id_college_id").val() == 0 )
        {
            alert("Select College Name");
            $("#id_college_id").focus();
            return false;
        }        
    }
</script>