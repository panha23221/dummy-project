<?php 
    include_once '../common_html_php_code/header.php';

    error_reporting( error_reporting() & ~E_NOTICE );
    $str = base64_decode( $_GET['str'] ); 
    $date_period_sql = base64_decode( $_GET['date_period'] );
    $sub_id = base64_decode( $_GET['sub_id'] );
    //echo $str;
    function cal_avg($total_ans, $r_id)
    {
        $percent = ($total_ans/($r_id));
        return number_format((float)$percent, 2, '.', '');
    }

    if($str=='select * from feedback_master order by feed_date asc')
    {
        echo "Input is not correct";
        exit();
    }
    else
    {
        $res_date_period = mysqli_query($conn, $date_period_sql) or die(mysqli_error($conn));
        $date_period_str = "";
        while ($row = mysqli_fetch_array($res_date_period)) {
            $date_period_str = "(". date("d-m-Y", strtotime($row["from_date"])). " - ". date("d-m-Y", strtotime($row["to_date"])).")";
        }
        //echo $str;
        $res = mysqli_query($conn, $str) or die(mysqli_error($conn));

        $remark_count = 0;	
        if(mysqli_num_rows($res)==0)
        {
            echo "No Record Found!";
            exit;
        }
        else
        {
            $total_ans1=0;
            $total_ans2=0;
            $total_ans3=0;
            $total_ans4=0;
            $total_ans5=0;
            $total_ans6=0;
            $total_ans7=0;
            $total_ans8=0;
            $total_ans9=0;
            $total_ans10=0;
            //$total_ans11=0;
            //$total_ans12=0;
            //$total_ans13=0;
            //$total_ans14=0;
            //$total_ans15=0;
            $i=0;
            while($myrow=mysqli_fetch_array($res))
            {
                $total_ans1 = $total_ans1 + $myrow['ans1'];
                $total_ans2 = $total_ans2 + $myrow['ans2'];
                $total_ans3 = $total_ans3 + $myrow['ans3'];
                $total_ans4 = $total_ans4 + $myrow['ans4'];
                $total_ans5 = $total_ans5 + $myrow['ans5'];
                $total_ans6 = $total_ans6 + $myrow['ans6'];
                $total_ans7 = $total_ans7 + $myrow['ans7'];
                $total_ans8 = $total_ans8 + $myrow['ans8'];
                $total_ans9 = $total_ans9 + $myrow['ans9'];
                $total_ans10 = $total_ans10 + $myrow['ans10'];
                //$total_ans11 = $total_ans11 + $myrow['ans11'];
                //$total_ans12 = $total_ans12 + $myrow['ans12'];
                //$total_ans13 = $total_ans13 + $myrow['ans13'];
                //$total_ans14 = $total_ans14 + $myrow['ans14'];
                //$total_ans15 = $total_ans15 + $myrow['ans15'];

                if($i == 0)
                {
                    $branch_name = branch_name($conn, $myrow['b_id']);
                    $batch_name = batch_name($conn, $myrow['batch_id']);
                    $sem_name = sem_name($conn, $myrow['sem_id']);
                    $division_name = division_name($conn, $myrow['division_id']);
                    $faculty_name = faculty_name($conn, $myrow['f_id']);
                    $subject_name = subject_name($conn, $myrow['sub_id']);
                }

                $i++;						  						  

                if($myrow['remark']!=NULL)
                {	
                    $arr_remark[$remark_count] = $myrow['remark'];
                    $remark_count++;
                }	
            }
            $ans1 = cal_avg($total_ans1, $i);
            $ans2 = cal_avg($total_ans2, $i);
            $ans3 = cal_avg($total_ans3, $i);
            $ans4 = cal_avg($total_ans4, $i);
            $ans5 = cal_avg($total_ans5, $i);
            $ans6 = cal_avg($total_ans6, $i);
            $ans7 = cal_avg($total_ans7, $i);
            $ans8 = cal_avg($total_ans8, $i);
            $ans9 = cal_avg($total_ans9, $i);
            $ans10 = cal_avg($total_ans10, $i);
            //$ans11 = cal_avg($total_ans11, $i);
            //$ans12 = cal_avg($total_ans12, $i);
            //$ans13 = cal_avg($total_ans13, $i);
            //$ans14 = cal_avg($total_ans14, $i);
            //$ans15 = cal_avg($total_ans15, $i);
        }								
?>																						
        <script type="text/javascript">
            function showTooltip(x, y, contents) {
                $('<div id="tooltip">' + contents + '</div>').css( {
                    position: 'absolute',
                    display: 'none',
                    top: y + 5,
                    left: x + 5,
                    border: '1px solid #fdd',
                    padding: '2px',
                    'background-color': '#fee',
                    opacity: 0.80
                }).appendTo("body").fadeIn(200);
            }
            $(function() {
                    var previousPoint = null;
                    $("#placeholder").bind("plothover", function (event, pos, item) {
                        $("#x").text(pos.x.toFixed(2));
                        $("#y").text(pos.y.toFixed(2));								
                        if (item) {
                            if (previousPoint != item.dataIndex) {
                                previousPoint = item.dataIndex;

                                $("#tooltip").remove();
                                var x = item.datapoint[0].toFixed(2),
                                    y = item.datapoint[1].toFixed(2);																	
                                showTooltip(item.pageX, item.pageY, (y*10) + "%" );
                            }
                        }
                        else {
                            $("#tooltip").remove();
                            previousPoint = null;            
                        }					
                    });
            });


            $(function() {
                var myData = [[1, <?php echo $ans1;?>], [2, <?php echo $ans2;?>], [3, <?php echo $ans3;?>], [4, <?php echo $ans4;?>], [5, <?php echo $ans5;?>], 
                                                [6, <?php echo $ans6;?>], [7, <?php echo $ans7;?>], [8, <?php echo $ans8;?>], [9, <?php echo $ans9;?>], [10, <?php echo $ans10;?>]];

                var Options = { 
                        xaxis: {ticks: [[1, '<?php echo que_one_word($conn, 1);?>'], [2, '<?php echo que_one_word($conn, 2);?>'], [3, '<?php echo que_one_word($conn, 3);?>'], [4, '<?php echo que_one_word($conn, 4);?>'], [5, '<?php echo que_one_word($conn, 5);?>'],
                                                        [6, '<?php echo que_one_word($conn, 6);?>'], [7, '<?php echo que_one_word($conn, 7);?>'], [8, '<?php echo que_one_word($conn, 8);?>'], [9, '<?php echo que_one_word($conn, 9);?>'], [10, '<?php echo que_one_word($conn, 10);?>']] },

                        bars: { show: true, align:"center" },
                        grid: { hoverable: true, clickable: true, xaxis: false },
                }

                $.plot($("#placeholder"), [{data: myData}], Options);				
            });
        </script>
        <div class="table-responsive">
            <table class="table table-striped table-sm" >
                <thead class="thead-dark">
                    <tr>
                        <th><!--Roll No--></th>
                        <th>Faculty</th>
                        <th>Subject</th>
                        <th>College</th>
                        <th>Branch</th>
                        <th>Batch</th>
                        <th>Semester</th>
                        <th>Division</th>                                               
                    </tr>
                </thead>
                <?php
                    $sql_subj_details = "SELECT cm.c_name, sm.sub_id, sm.sub_name, bm.batch_name, brm.b_name, sem.sem_name, dm.division, fm.f_name, fm.l_name ".
                        "FROM subject_master as sm ".
                        "INNER JOIN faculty_master fm on fm.f_id = sm.f_id ".
                        "INNER JOIN batch_master bm on bm.batch_id = sm.batch_id ".
                        "INNER JOIN branch_master brm on brm.b_id = sm.branch_id ".
                        "INNER JOIN semester_master sem on sem.sem_id = sm.sem_id ".
                        "INNER JOIN division_master dm on dm.id = sm.division_id ". 
                        "INNER JOIN college_master cm on cm.c_id = fm.c_id ". 
                        "WHERE sub_id in ($sub_id) ";
                    //echo $sql_subj_details;
                    $res_subj_details = mysqli_query($conn, $sql_subj_details) or die("error in query");

                    while ($row = mysqli_fetch_array($res_subj_details)) {
                        //echo $row["sub_name"];

                        $table_str = "<tr>";
                        $table_str .=  "<td>&nbsp;</td>";                                                
                        $table_str .=  "<td>".$row["f_name"]." ".$row["l_name"]."</td>";
                        $table_str .=  "<td>".$row["sub_name"]."</td>";
                        $table_str .=  "<td>".$row["c_name"]."</td>";
                        $table_str .=  "<td>".$row["b_name"]."</td>";
                        $table_str .=  "<td>".$row["batch_name"]."</td>";
                        $table_str .=  "<td>".$row["sem_name"]."</td>";
                        $table_str .=  "<td>".$row["division"]."</td>";
                        $table_str .= "</tr>";
                        echo $table_str;
                    }                                                                                        
                ?>
            </table>
        </div>
        <div class="row">
            <div class="col-12">
                <div align="center"><h3>Questions v/s Average Rating</h3></div>	
                <div id="placeholder" style="height:300px;width:100%;"></div>
            </div>
        </div>
<?php				
        if($remark_count > 0){
            echo '<div class="row"><div class="col-12"><strong>Remark(s):-<strong></div></div>';
            echo '<div class="table-responsive"><table class="table table-striped table-sm">';
            $j=0;

            for($row=0; $row<($remark_count)/4; $row++)
            {
                echo '<tr>';			
                for($col=0;$col<4;$col++)
                {	
                    if($arr_remark[$j]!=NULL)
                    {
                        echo '<td>'.'&nbsp;'.$arr_remark[$j].'</td>';
                        $j++;
                    }
                }
                echo '</tr>';
            }
            echo '</table></div>';
        }
    
    }//end of else
                 
    include_once '../common_html_php_code/footer.php';
?>
