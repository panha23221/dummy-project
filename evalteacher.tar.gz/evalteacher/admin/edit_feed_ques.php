<?php 
    include_once '../common_html_php_code/header.php';
    
    $q_id = (isset($_GET['q_id'])) ? sanitize($conn, $_GET['q_id']): 0;
    if(isset($_POST['submit']))
    {
        $q_id = sanitize($conn, $_POST['q_id']);
        $one_word = sanitize($conn, $_POST['one_word']);
        $que = sanitize($conn, $_POST['que']);
                
        if(empty($que)){
            $_SESSION['error_msg'] = "Please enter feedback question";            
        }
        else if(empty($one_word)) {
            $_SESSION['error_msg'] = "Please enter one word for question";
        }
        else{
            
            $result = mysqli_query($conn, "UPDATE feedback_ques_master SET ques='$que', one_word='$one_word' WHERE q_id='$q_id'");
            $_SESSION['success_msg'] = "Question updated Successfully!";            
            header( "refresh:0;url=feed_ques.php" );
            exit();
        }
        
    }
        
    $result = mysqli_query($conn, "SELECT * FROM feedback_ques_master WHERE q_id='$q_id' ");
    while($myrow = mysqli_fetch_assoc($result))
    {
        $que = $myrow["ques"];
        ShowSessionMsg();
?>
        <h1 class="h2">Update Feedback Question</h1>  
        <form class="form" method="post" class="form" action="<?php echo $_SERVER['PHP_SELF'] ?>" >
            <input type="hidden" name="q_id" value="<?php echo $myrow['q_id']?>" />
            <div class="form-group">
                <label class="control-label col-sm-2"><b>Question</b></label>
                <div class="col-sm-4">
                    <textarea class="form-control" id="id_que" name="que" placeholder="Enter question"><?php echo $que; ?></textarea>
                    
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-sm-2"><b>One word for que<b></label>
                <div class="col-sm-4">
                    
                    <input type="text" class="form-control" id="id_one_word" name="one_word" placeholder="Enter one word for question" value="<?php echo $myrow['one_word']?>"/>
                </div>
            </div>
            <div class="form-group">
                <div class="col-sm-offset-2 col-sm-4">
                    <button type="submit" class="btn btn-default" name="submit" id="id_submit" value="Update">Update</button>
                    <a href='feed_ques.php' class="btn btn-danger">Back</a>
                </div>
            </div>
        </form>
            
<?php
    }//end of while loop
    
    include_once '../common_html_php_code/footer.php';
?>
                