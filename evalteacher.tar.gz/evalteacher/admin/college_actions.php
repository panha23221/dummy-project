<?php 
    
    include_once '../common_html_php_code/header.php';
    
    $action = (int)((isset($_GET['action'])) ? sanitize($conn, $_GET['action']): ADD_ACTION ); 
    $college_name = '';
    
    if($action == DELETE_ACTION ){
        delete_record($_GET, $conn, "college_master", "c_id", "college.php");
        exit();
        
    }else if($action == UPDATE_ACTION){
        $college_id = (isset($_GET['id'])) ? sanitize($conn, $_GET['id']): 0;
        $result = mysqli_query($conn, "SELECT c_id as college_id, c_name as college_name FROM college_master WHERE c_id='$college_id' ");
        while($myrow = mysqli_fetch_assoc($result))
        {
            $college_name = $myrow["college_name"];
            $college_id = $myrow["college_id"];
        }
    }
    
    
    if(isset($_POST['submit']))
    {
        $college_name = array_key_exists('college_name', $_POST) ? sanitize($conn, $_POST['college_name']) : '';
        $college_id = array_key_exists('college_id', $_POST) ? sanitize($conn, $_POST['college_id']) : '';
        $action = sanitize($conn, $_POST['submit']);
        
        if(empty($college_name)){
            $_SESSION['error_msg'] = "Please enter college name.";            
        }
        else{
            if($action == ADD_ACTION){
                $dup = "select * from college_master where c_name = '$college_name'";
                $dup_res = mysqli_query($conn, $dup) or die(mysqli_error($conn));
                if(mysqli_num_rows($dup_res)==1)
                {            
                    $_SESSION['error_msg'] = "College name is already available in database.";            
                }
                else
                {
                    mysqli_query($conn, "INSERT INTO college_master (c_name) VALUES ('$college_name')");            
                    $_SESSION['success_msg'] = "College is added Successfully!";                
                    header( "refresh:0;url=college.php" );
                    exit();
                }
                
            }
            else if($action == UPDATE_ACTION){
                //check duplication
                $dup="select * from college_master where c_name='$college_name' and c_id != $college_id";
                $dup_res = mysqli_query($conn, $dup) or die(mysqli_error($conn));
                if(mysqli_num_rows($dup_res) == 1)
                {            
                    $_SESSION['error_msg'] = "College name is already available in database.";            
                }
                else
                {                                
                    $result = mysqli_query($conn, "UPDATE college_master SET c_name='$college_name' WHERE c_id='$college_id'");
                    $_SESSION['success_msg'] = "College is updated successfully!";            
                    header( "refresh:0;url=college.php" );
                    exit();
                }
            }
        }
    }
        
    ShowSessionMsg();
    include_once 'college_form.php';
    include_once '../common_html_php_code/footer.php';
?>
<script language="javascript" type="text/javascript">
    function chkForm()
    {
        /*if ( $("#id_college_name").val().length < 1 )
        {
            alert("Enter college name");	
            $("#id_college_name").focus();		
            return false;
        }*/           
    }
</script>