<?php
include_once '../common_html_php_code/header.php';

if (isset($_POST['submit'])) {
    // Define $myusername and $mypassword
    $myusername = sanitize($conn, $_POST['myusername']);
    $mypassword = sanitize($conn, $_POST['mypassword']);

    $sql    = "SELECT * FROM members WHERE username='$myusername' and password=md5('$mypassword')";
    $result = mysqli_query($conn, $sql);
    $count  = mysqli_num_rows($result);

    if ($count == 1) {
        // Register $myusername, $mypassword and redirect to file "login_success.php"
        $_SESSION['myusername'] = $myusername;
        header("location:login_success.php");
        exit();
    } else {
        $_SESSION['error_msg'] = "Wrong Username or Password";
    }
}

?>
    <div class="back">
        <div class="div-center">
            <?php ShowSessionMsg();?>
            <div class="login-form">
                <h3 align='center'>Admin Login</h3>
                <form name="form1" method="post" action="<?php echo $_SERVER["PHP_SELF"]; ?>">
                    <label><b>Username</b></label>
                    <div class="form-group">
                        <input type="text" name="myusername" class="form-control" placeholder="Enter username" id="myusername">
                    </div>
                    <label><b>Password</b></label>
                    <div class="form-group">
                        <input type="password" name="mypassword" class="form-control" placeholder="Enter password" id="mypassword">
                    </div>
                    <div class="form-group">
                        <div class="col-xs-offset-2 col-xs-10">
                            <button type="submit" name="submit" value="submit" class="btn btn-primary">Login</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php
include_once '../common_html_php_code/footer.php';
?>
