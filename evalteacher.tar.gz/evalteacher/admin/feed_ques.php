<?php 
    include_once '../common_html_php_code/header.php';
    ShowSessionMsg();
?>
    
    <div class="table-responsive">
        <h2>Feedback questions</h2>
        <table class="table table-striped table-sm" >
            <thead class="thead-dark">
                <tr>
                    <th><b>Id</b></th>
                    <th><b>Question</b></th>
                    <th><b>Graph word</b></th>
                    <th><b>Actions</b></th>
                </tr>
            </thead>

            <?php

                $result = mysqli_query($conn, "SELECT * FROM feedback_ques_master ORDER BY q_id");                        
                $i=1;
                while($myrow = mysqli_fetch_array($result))
                {
                    echo '<tr>';
                    echo "<td>".$i."</td>";$i++;
                    echo "<td>".$myrow['ques']."</td>";
                    echo "<td>".$myrow['one_word']."</td>";
                    echo "<td>".
                            "<a href=\"edit_feed_ques.php?q_id=$myrow[q_id]\" title='Edit question' class=\"button\"><i class=\"fas fa-edit fa-lg\"></i></a> ".
                            "</td>";
                    echo '</tr>';  

                }//end of loop
            ?>
        </table>
    </div>
<?php
    include_once '../common_html_php_code/footer.php';
?>