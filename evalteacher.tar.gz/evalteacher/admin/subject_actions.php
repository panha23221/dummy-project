<?php 
    include_once '../common_html_php_code/header.php';
    $action = (int)((isset($_GET['action'])) ? sanitize($conn, $_GET['action']): ADD_ACTION);
    $f_id = (isset($_GET['f_id'])) ? sanitize($conn, $_GET['f_id']): 0;
    $branch_id = '';
    $sub_name = '';
    $batch_id = '';
    $sem_id = '';
    $division_id = '';
    
    if($action == DELETE_ACTION){
        delete_record($_GET, $conn, "subject_master", "sub_id", "subject.php?id=".$f_id);
        exit();
    }
    else if($action == UPDATE_ACTION){
        $sub_id = (isset($_GET['id'])) ? sanitize($conn, $_GET['id']): 0;
        $sub_result = mysqli_query($conn, "SELECT * FROM subject_master  where sub_id='$sub_id'") or die("error in query");
        while($sub_myrow = mysqli_fetch_array($sub_result))
        {
            $f_id = $sub_myrow['f_id'];
            $branch_id = $sub_myrow['branch_id'];
            $sub_name = $sub_myrow['sub_name'];
            $batch_id = $sub_myrow['batch_id'];
            $sem_id = $sub_myrow['sem_id'];
            $division_id = $sub_myrow['division_id'];
        }
    }
    
    if(isset($_POST['submit']))
    {
        $sub_id = array_key_exists('sub_id', $_POST) ? sanitize($conn, $_POST['sub_id']) : '';
        $f_id = array_key_exists('f_id', $_POST) ? sanitize($conn, $_POST['f_id']) : '';
        $sub_name = array_key_exists('sub_name', $_POST) ? sanitize($conn, $_POST['sub_name']) : '';
        $branch_id = array_key_exists('branch_name', $_POST) ? sanitize($conn, $_POST['branch_name']) : '';
        $batch_id = array_key_exists('batch_name', $_POST) ? sanitize($conn, $_POST['batch_name']) : '';
        $sem_id = array_key_exists('sem_name', $_POST) ? sanitize($conn, $_POST['sem_name']) : '';
        $division_id = array_key_exists('division', $_POST) ? sanitize($conn, $_POST['division']) : '';
        $action = sanitize($conn, $_POST['submit']);
        
        if(empty($sub_name))
        {  
            $_SESSION['error_msg'] = "Error: Add subject name for the faculty.";             
        }
        else if(empty($f_id) || $f_id <= 0 || $f_id == null)
        {  
            $_SESSION['error_msg'] = "Error: Select faculty.";             
        }
        else if(empty($branch_id) || $branch_id <= 0 || $branch_id == null)
        {  
            $_SESSION['error_msg'] = "Error: Select branch.";             
        }
        else if(empty($batch_id) || $batch_id <= 0 || $batch_id == null)
        {  
            $_SESSION['error_msg'] = "Error: Select batch.";             
        }
        else if(empty($sem_id) || $sem_id <= 0 || $sem_id == null)
        {  
            $_SESSION['error_msg'] = "Error: Select semester.";             
        }
        else if(empty($division_id) || $division_id <= 0 || $division_id == null)
        {  
            $_SESSION['error_msg'] = "Error: Select division.";             
        }
        else{
            
            if($action == ADD_ACTION){
                $dup="select * from subject_master where sub_name='".$sub_name."' and f_id='$f_id' and sem_id='$sem_id' and branch_id='$branch_id' ".
                    " and batch_id='$batch_id' and division_id='$division_id' ";
                $dup_res=mysqli_query($conn, $dup) or die(mysqli_error($conn));
                if(mysqli_num_rows($dup_res) == 1)
                {
                    $_SESSION['error_msg'] = "Subject name is already available in table";
                }
                else
                {
                    //run the query which adds the data gathered from the form into the database
                    $sql = "INSERT INTO subject_master (sub_name,f_id,sem_id,branch_id,batch_id,division_id) ".
                           "VALUES ('$sub_name','$f_id','$sem_id','$branch_id','$batch_id','$division_id')";
                    mysqli_query($conn, $sql);
                    $_SESSION['success_msg'] = "Subject is added Successfully!";            
                    header( "refresh:0;url=subject.php?f_id=".$f_id );
                    exit();
                }
            }
            else if($action == UPDATE_ACTION){
                //check duplication
                $dup="select * from  subject_master where sub_name='".$sub_name."' and sem_id =".$sem_id." and ".
                        " f_id=".$f_id." and batch_id='".$batch_id."' and division_id='".$division_id."' and sub_id!=".$sub_id;

                $dup_res = mysqli_query($conn, $dup) or die(mysqli_error($conn));
                if(mysqli_num_rows($dup_res) == 1)
                {
                    $_SESSION['error_msg'] = "Subject name is already available in table";
                }
                else
                {                                
                    mysqli_query($conn, "UPDATE  subject_master  SET sub_name='$sub_name', sem_id='$sem_id', f_id='$f_id', batch_id='$batch_id', ".
                            " division_id='$division_id' WHERE sub_id='$sub_id'");
                    $_SESSION['success_msg'] = "Subject detail is updated successfully!";            
                    header( "refresh:0;url=subject.php?f_id=".$f_id );
                    exit();
                }
            }
        }
    }
    ShowSessionMsg();
    include_once 'subject_form.php';
    include_once '../common_html_php_code/footer.php';
?>                                   
<script language="javascript" type="text/javascript">

    function chkForm(form)
    {

        if ( $("#id_branch_id").val() <= 0 )
        {
            alert("Select branch");	
            $("#id_branch_id").focus();		
            return false;
        }
        if ( $("#id_sub_name").val().length < 1 )
        {
            alert("Enter subject name");	
            $("#id_sub_name").focus();		
            return false;
        }        
        if ($("#id_batch_id").val() <= 0 )
        {
            alert("Select Batch Name");
            $("#id_batch_id").focus();
            return false;
        }
        
        if ($("#id_semester_id").val() <= 0 )
        {
            alert("Select Semester Name");
            $("#id_semester_id").focus();
            return false;
        }
        
        if ($("#id_division").val() <= 0 )
        {
            alert("Select Division");
            $("#id_division").focus();
            return false;
        }
    }
</script>