<h1 class="h2"><?php echo ($action == UPDATE_ACTION) ? UPDATE_ACTION_TEXT : ADD_ACTION_TEXT ?> Subject</h1>
<form method="post" class="form" action="<?php echo $_SERVER['REQUEST_URI'] ?>" name="update_sub" onsubmit="return chkForm();">
    <?php if ($action == UPDATE_ACTION){ ?>
        <input type="hidden" name="sub_id" value="<?php echo $sub_id ?>" />
    <?php } ?>
    <input type="hidden" name="f_id" value="<?php echo $f_id ?>" />
    <div class="form-group">
        <label class="control-label col-sm-2"><b>Faculty</b></label>
        <div class="col-sm-4">
            <?php
                $sql = "SELECT * FROM faculty_master where f_id='$f_id'";                                    
                $f_result = mysqli_query($conn, $sql) or die("error in query");                                    
                $f_myrow = mysqli_fetch_array($f_result);                                    
            ?>
            <h3><?php echo $f_myrow['f_name'].'&nbsp;'.$f_myrow['l_name'].'&nbsp ('.college_name($conn, $f_myrow['c_id']).')' ?></h3>
        </div>
    </div>

    <div class="form-group">
        <label class="control-label col-sm-2"><b>Branch</b></label>
        <div class="col-sm-4">
            <?php

                $sel_branch = "select * from branch_master where college_id=".$f_myrow['c_id'];
                $res_branch = mysqli_query($conn, $sel_branch) or die(mysqli_error($conn));
                $branch_array = array();
                while($branch_combo = mysqli_fetch_array($res_branch))
                {							
                    $branch_array[] = array('id' => $branch_combo['b_id'],
                                            'text' => $branch_combo['b_name']);								  
                }
                $default = $branch_id;
                echo tep_draw_pull_down_menu('branch_name', $branch_array, $default, ' id="id_branch_id" class="custom-select" ');
            ?>
        </div>
    </div>
    <div class="form-group">
        <label class="control-label col-sm-2"><b>Subject</b></label>
        <div class="col-sm-4">
            <input type="text" class="form-control" id="id_sub_name" name="sub_name" value="<?php echo $sub_name ?>" onkeypress="return isCharOnly(event);"/>
        </div>
    </div>

    <div class="form-group">
        <label class="control-label col-sm-2"><b>Batch</b></label>
        <div class="col-sm-4">
            <?php
                $sel_batch="select * from batch_master ";
                $res_batch=mysqli_query($conn, $sel_batch) or die(mysqli_error($conn));
                $batch_array = array();
                $default = 1;
                while($batch_combo=mysqli_fetch_array($res_batch))
                {			
                    $default = $batch_combo['batch_id'];
                    $batch_array[] = array('id' => $batch_combo['batch_id'],
                                           'text' => $batch_combo['batch_name']);								  
                }
                $default = $batch_id;
                echo tep_draw_pull_down_menu('batch_name',$batch_array, $default, ' id="id_batch_id" class="custom-select" ');
            ?>
        </div>
    </div>

    <div class="form-group">
        <label class="control-label col-sm-2"><b>Semester</b></label>
        <div class="col-sm-4">
            <?php
                $sel_sem="select * from semester_master ";
                $res_sem=mysqli_query($conn, $sel_sem) or die(mysqli_error($conn));

                while($sem_combo=mysqli_fetch_array($res_sem))
                {							
                    $sem_array[] = array('id' => $sem_combo['sem_id'],
                                         'text' => $sem_combo['sem_name']);								  
                }
                $default = $sem_id;
                echo tep_draw_pull_down_menu('sem_name', $sem_array, $default, ' id="id_semester_id" class="custom-select" ');
            ?>
        </div>
    </div>

    <div class="form-group">
        <label class="control-label col-sm-2"><b>Division</b></label>
        <div class="col-sm-4">
            <?php
                $sel_division="select * from division_master ";
                $res_division=mysqli_query($conn, $sel_division) or die(mysqli_error($conn));

                while($division_combo = mysqli_fetch_array($res_division))
                {							
                    $division_array[] = array('id' => $division_combo['id'],
                                              'text' => $division_combo['division']);								  
                }
                $default = $division_id;
                echo tep_draw_pull_down_menu('division', $division_array, $default, ' id="id_division" class="custom-select" ');
            ?>
        </div>
    </div>

    <div class="form-group">
        <div class="col-sm-offset-2 col-sm-4">
            <button type="submit" class="btn btn-default" name="submit" id="id_submit" value="<?php echo $action ?>"><?php echo ($action == UPDATE_ACTION) ? UPDATE_ACTION_TEXT : ADD_ACTION_TEXT ?></button>
            <a href='subject.php?f_id=<?php echo $f_id ?>' class="btn btn-danger">Back</a>
        </div>
    </div>
</form>