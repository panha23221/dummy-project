<?php 
    include_once '../common_html_php_code/header.php';
    if(isset($_POST['action']) && $_POST['action'] == DELETE_ACTION){
        delete_record($_POST, $conn, array("subject_master", "faculty_master"), "f_id", "faculty.php");
        exit();
    }
    ShowSessionMsg();
?>
    <form method="post" class="form" action="<?php echo $_SERVER['REQUEST_URI'] ?>" id="id_form">
        <h2>
            <a href='faculty_actions.php' class="btn btn-primary" ><i class="fas fa-plus fa-sm"></i> Add faculty</a>
            <button type="submit" class="btn btn-danger" name="action" id="id_deletebtn" value="<?php echo DELETE_ACTION ?>">Delete selected</button>
        </h2>                
        <div class="table-responsive">
            <table class="table table-striped table-sm">
                <thead class="thead-dark">
                    <tr>
                        <th><input type='checkbox' name="select-all" id="select-all" /></th>
                        <th><b>Faculty Name</b></th>                
                        <th><b>Actions</b></th>
                    </tr>
                </thead>

                <tbody>
                    <?php
                        $group_by = mysqli_query($conn, "SELECT distinct(c_id) FROM faculty_master  ORDER BY c_id ASC, f_id ASC");                       
                        while($group_c_id = mysqli_fetch_array($group_by))
                        {
                            echo '<tr><td colspan=3 align=center><b>'.college_name($conn, $group_c_id['c_id']).'</b></td></tr>';                   
                            $result = mysqli_query($conn, "SELECT * FROM faculty_master where c_id='".$group_c_id['c_id']."' ORDER BY c_id,f_id");
                            //lets make a loop and get all news from the database
                            $i=1;
                            if(mysqli_num_rows($result)>0)
                            {
                                while($myrow = mysqli_fetch_array($result))
                                {
                                    echo '<tr>';
                                    //echo "<td align=center>".$i."</td>";
                                    //$i++;
                                    echo "<td><input type='checkbox' name='id[ ]' value='".$myrow['f_id']."' /></td>";
                                    echo "<td>".$myrow['f_name'].'&nbsp;'.$myrow['l_name']." </td>";                                
                                    echo "<td>".
                                            '<a href="faculty_actions.php?action='.UPDATE_ACTION.'&id='.$myrow['f_id'].'" title="Edit faculty" class="button"><i class="fas fa-edit fa-lg"></i></a> '.
                                            '<a href="faculty_actions.php?action='.DELETE_ACTION.'&id='.$myrow['f_id'].'" title="Delete faculty" class="delete-button button"><i class="fas fa-trash-alt fa-lg"></i></a> '.
                                            '<a href="subject.php?f_id='.$myrow['f_id'].'" title="Subject list" class="button"><i class="fas fa-book fa-lg"></i></a>'.
                                        "</td>";
                                    echo '</tr>';
                                }
                            }
                            else
                            {
                                echo '<tr><td colspan=2 align=center>No record found!</td></tr>';
                            }
                        }
                    ?>
                </tbody>
            </table>
        </div>
    </form>
<?php
    include_once '../common_html_php_code/footer.php';
?>