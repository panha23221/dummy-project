<?php
    include('db_detail.php');

    $conn = mysqli_connect($dbhost, $dbuser, $dbpass) or die('Error connecting to mysql');
    mysqli_select_db($conn, $dbname) or die(mysqli_error($conn));

    // Set max rating number
    $MAX_RATING = 5;

    function cleanupValue(){
        return '';
    }
    function cleanInput($input) {

        $search = array(
            '@<script[^>]*?>.*?</script>@si',   // Strip out javascript
            '@<[\/\!]*?[^<>]*?>@si',            // Strip out HTML tags
            '@<style[^>]*?>.*?</style>@siU',    // Strip style tags properly
            '@<![\s\S]*?--[ \t\n\r]*>@'         // Strip multi-line comments
        );

        $output = preg_replace_callback($search, 'cleanupValue', $input);
        return $output;
    }

    function sanitize($conn, $input) {
        
        if (is_array($input)) {
            //foreach($input as $var=>$val) {
            //    $output[$var] = sanitize($val);
            //}
            foreach ($input as $val) {
                $output[] = sanitize($conn, $val);
            }
        }
        else {
            if (get_magic_quotes_gpc()) {
                // To protect MySQL injection (more detail about MySQL injection)
                $input = stripslashes($input);
            }
            $input  = cleanInput($input);
            $output = mysqli_real_escape_string($conn, $input);
        }
        return $output;
    }
    
    function ShowSessionMsg(){
        if(isset($_SESSION['error_msg']) && !empty($_SESSION['error_msg'])){                   
            echo '<div class="alert alert-danger" role="alert">'.$_SESSION['error_msg'].'</div>';                            
            unset($_SESSION['error_msg']);
        }

        if(isset($_SESSION['success_msg']) && !empty($_SESSION['success_msg'])){                   
            echo '<div class="alert alert-success" role="alert">'.$_SESSION['success_msg'].'</div>';                            
            unset($_SESSION['success_msg']);
        }
    }
    

?>