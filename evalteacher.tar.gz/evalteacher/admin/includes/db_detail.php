<?php

$system = 'dev';

$db_setting = array(
    'production' => array(
        'dbhost' => 'localhost',
        'dbuser' => 'evalteac_demo',
        'dbpass' => 'evalteac_demo',
        'dbname' => 'evalteac_demo'
    ),
    'dev' => array(
        'dbhost' => 'localhost',
        'dbuser' => 'root',
        'dbpass' => 'root',
        'dbname' => 'feedback_full'
    )
);

$dbhost = $db_setting[$system]['dbhost'];
$dbuser = $db_setting[$system]['dbuser'];
$dbpass = $db_setting[$system]['dbpass'];
$dbname = $db_setting[$system]['dbname'];

?>
