<?php
//////////////////////////////////////////////////////////////////*****/////////////////////////////////////////////////////////////////////////////////////
//                                                             Feedback Pro v1                                                                             //
//                                                        Faculty Evaluation System                                                                         //
//                                                        Developed By Shrenik Patel                                                                         //
//                                                             July 27, 2009                                                                                 //
//                                                                                                                                                         //
//  Tis program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by                  //
//  the Free Software  Foundation; either version 2 of the License, or (at your option) any later version.                                                 //
//                                                                                                                                                         //
//  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or      //
//  FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.                                                                 //
//                                                                                                                                                         //
//////////////////////////////////////////////////////////////////*****//////////////////////////////////////////////////////////////////////////////////////
//configuration file

function college_name($conn, $c_id)
{
    $sel_c  = "select * from college_master where c_id=" . $c_id;
    $res    = mysqli_query($conn, $sel_c) or die(mysqli_error($conn));
    $c_name = mysqli_fetch_array($res);
    return $c_name['c_name'];
}

function branch_name($conn, $b_id)
{
    $sel_b  = "select * from branch_master where b_id=" . $b_id;
    $res    = mysqli_query($conn, $sel_b) or die(mysqli_error($conn));
    $b_name = mysqli_fetch_array($res);
    return $b_name['b_name'];
}

function batch_name($conn, $batch_id)
{
    $sel_b  = "select * from batch_master where batch_id=" . $batch_id;
    $res    = mysqli_query($conn, $sel_b) or die(mysqli_error($conn));
    $b_name = mysqli_fetch_array($res);
    return $b_name['batch_name'];
}

function sem_name($conn, $sem_id)
{
    $sel_s  = "select * from semester_master where sem_id=" . $sem_id;
    $res    = mysqli_query($conn, $sel_s) or die(mysqli_error($conn));
    $s_name = mysqli_fetch_array($res);
    return $s_name['sem_name'];
}

function division_name($conn, $division_id)
{
    $sel_s  = "select * from division_master where  id=" . $division_id;
    $res    = mysqli_query($conn, $sel_s) or die(mysqli_error($conn));
    $s_name = mysqli_fetch_array($res);
    return $s_name['division'];
}

function subject_name($conn, $sub_id)
{
    $sel_s  = "select * from subject_master where sub_id=" . $sub_id;
    $res    = mysqli_query($conn, $sel_s) or die(mysqli_error($conn));
    $s_name = mysqli_fetch_array($res);
    return $s_name['sub_name'];
}

function faculty_name($conn, $f_id)
{
    $sel_s  = "select * from faculty_master where f_id=" . $f_id;
    $res    = mysqli_query($conn, $sel_s) or die(mysqli_error($conn));
    $s_name = mysqli_fetch_array($res);
    return $s_name['f_name'] . ' ' . $s_name['l_name'];
}

function que_one_word($conn, $id, $full_question = false)
{
    $sel_s  = "select * from  feedback_ques_master where q_id=" . $id;
    $res    = mysqli_query($conn, $sel_s) or die(mysqli_error($conn));
    $s_name = mysqli_fetch_array($res);
    if ($full_question) {
        return $s_name['ques'];
    } else {
        return $s_name['one_word'];
    }
}

function get_que($conn, $id)
{
    $sel_s  = "select * from  feedback_ques_master where q_id=" . $id;
    $res    = mysqli_query($conn, $sel_s) or die(mysqli_error($conn));
    $s_name = mysqli_fetch_array($res);
    return $s_name['ques'];
}


function tep_draw_pull_down_menu($name, $values, $default = 1, $parameters = '', $required = false) {


    $field = '<select name="' . $name . '"';

    if ($parameters!='') $field .= ' ' . $parameters;

    $field .= ' >';
    $field .='<option value=0></option>';
    
    for ($i=0, $j=0, $n = sizeof($values); $i<$n; $i++) {
      $field .= '<option value="'.$values[$i]['id'].'" ';
	    if ($default == $values[$i]['id']) {
          //if ($default[$j] == $values[$i]['id']) {
	  	    $j++;
          $field .= ' SELECTED';
      }
      $field .= ' >' .$values[$i]['text'] . '</option>';
    }
    $field .= '</select>';

    //if ($required == true) $field .= TEXT_FIELD_REQUIRED;

    return $field;
}
  
  
function tep_draw_pull_down_menu_sub($name, $values, $default = '10', $parameters = '', $required = false) {


    $field = '<select name="' . $name . '"';

    if ($parameters!='') $field .= ' ' . $parameters;

    $field .= ' >';

	$field .='<option value=0></option>';
    for ($i=0, $j=0,$n=sizeof($values); $i<$n; $i++) {
      $field .= '<option value="' . $values[$i]['id'] . '"';
      if ($default == $values[$i]['id']) {
	    $j++;
        $field .= ' SELECTED';
      }

      $field .= ' $str >' .$values[$i]['text'] . '</option>';
    }
    $field .= '</select>';

    //if ($required == true) $field .= TEXT_FIELD_REQUIRED;

    return $field;
}


function tep_draw_pull_down_menu_select_multiple($name, $values, $default = 1, $parameters = '', $required = false) {


    $field = '<select name="' . $name . '"';

    if ($parameters!='') $field .= ' ' . $parameters;

    $field .= ' >';
    //$field .='<option value=0></option>';
    
    $selected_values = explode(',', $default);
    
    for ($i=0, $j=0, $n = sizeof($values); $i<$n; $i++) {
        $field .= '<option value="'.$values[$i]['id'].'" ';
        if(in_array((int)$values[$i]['id'], $selected_values)){
	//if ($default == $values[$i]['id']) {           
            $j++;
            $field .= ' SELECTED';
        }
        $field .= ' >' .$values[$i]['text'] . '</option>';
    }
    $field .= '</select>';

    return $field;
}

function delete_record($request, $conn, $table_name, $delete_field_name, $redirect_page){
    $delete_record_id = null;
    
    if(array_key_exists('action', $request) && array_key_exists('id', $request)){
        //$id_array = explode(',', $request['id']);
        $id_array = $request['id'];
        
        $delete_record_id = (isset($id_array)) ? sanitize($conn, $id_array): 0;
        
        if(!is_null($delete_record_id) && $delete_record_id != 0){
    
            $delete_records = is_array($delete_record_id) ? implode(",", array_map('intval', $delete_record_id)) : $delete_record_id;

            if(isset($table_name) && isset($delete_field_name) && isset($delete_records)){
                
                if(is_array($table_name)){
                    foreach ($table_name as $t_name) {
                        if(!mysqli_query($conn, "DELETE FROM ".$t_name." WHERE ".$delete_field_name." in ($delete_records) ")){
                            $_SESSION['error_msg'] = mysqli_error($conn);
                            break;
                        }
                    }
                }
                else{
                    //mysqli_query($conn, "DELETE FROM ".$table_name." WHERE ".$delete_field_name." in ($delete_records) ");
                    if (!mysqli_query($conn, "DELETE FROM ".$table_name." WHERE ".$delete_field_name." in ($delete_records) "))
                    {
                        $_SESSION['error_msg'] = mysqli_error($conn);
                    }
                    else{
                        $_SESSION['success_msg'] = "Record is deleted successfully!";
                    }
                }
                
                header( "refresh:0;url=".$redirect_page );

            }
            else{
                $_SESSION['error_msg'] = "Something went wrong while deleteing record";
            }
        }
    }    
}