<?php

    include($ADD_ADMIN_PREFIX."session_chk.php");
    include($ADD_ADMIN_PREFIX."includes/db_config.php");
    include($ADD_ADMIN_PREFIX."includes/common_functions.php");
    
?>
