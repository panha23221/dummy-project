<h1 class="h2"><?php echo ($action == UPDATE_ACTION) ? UPDATE_ACTION_TEXT : ADD_ACTION_TEXT ?> faculty</h1>
<form method="post" class="form" action="<?php echo $_SERVER['REQUEST_URI'] ?>" name="update_fac" onsubmit="return chkForm();">
    <?php if ($action == UPDATE_ACTION){ ?>
        <input type="hidden" name="f_id" value="<?php echo $f_id ?>" />
    <?php } ?>
    <div class="form-group">
        <label class="control-label col-sm-2">First Name</label>
        <div class="col-sm-4">
            <input type="text" class="form-control" id="id_f_name" name="f_name" placeholder="Enter first name" value="<?php echo $f_name ?>" onkeypress="return isCharOnly(event);" />
        </div>
    </div>
    <div class="form-group">
        <label class="control-label col-sm-2">Last Name</label>
        <div class="col-sm-4">
            <input type="text" class="form-control" id="id_l_name" name="l_name" placeholder="Enter last name" value="<?php echo $l_name ?>" onkeypress="return isCharOnly(event);" />
        </div>
    </div>
    <div class="form-group">
        <label class="control-label col-sm-2">College</label>
        <div class="col-sm-4">
            <?php
                $sel_c ="select * from college_master";
                $res = mysqli_query($conn, $sel_c) or die(mysqli_error($conn));

                while($c_combo=mysqli_fetch_array($res))
                {							
                    $college_combo[] = array('id' => $c_combo['c_id'],
                                             'text' => $c_combo['c_name']);								  
                }
                $default = $c_id;
                echo tep_draw_pull_down_menu('college_id', $college_combo, $default, ' id="id_college_id" class="custom-select" ');
            ?>
        </div>
    </div>
    <div class="form-group">
        <div class="col-sm-offset-2 col-sm-4">
            <button type="submit" class="btn btn-default" name="submit" id="id_submit" value="<?php echo $action ?>"><?php echo ($action == UPDATE_ACTION) ? UPDATE_ACTION_TEXT : ADD_ACTION_TEXT ?></button>
            <a href='faculty.php' class="btn btn-danger">Back</a>
        </div>
    </div>
</form>