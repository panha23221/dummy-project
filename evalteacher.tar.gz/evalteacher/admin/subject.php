<?php 
    include_once '../common_html_php_code/header.php';
    $f_id = sanitize($conn, $_GET['f_id']);
    $f_result = mysqli_query($conn, "SELECT * FROM faculty_master  where f_id='".$f_id."'");
    $f_myrow = mysqli_fetch_array($f_result);
    
    if(isset($_POST['action']) && $_POST['action'] == DELETE_ACTION){
        delete_record($_POST, $conn, "subject_master", "sub_id", "subject.php?f_id=".$f_id);
        exit();
    }
    ShowSessionMsg();
?>
    <form method="post" class="form" action="<?php echo $_SERVER['REQUEST_URI'] ?>" id="id_form">
        <div class="row">
            <div class="col-sm-3">
                <a href='subject_actions.php?f_id=<?php echo $f_myrow["f_id"] ?>' class="btn btn-primary" ><i class="fas fa-plus fa-sm"></i> Add subject</a>
                <button type="submit" class="btn btn-danger" name="action" id="id_deletebtn" value="<?php echo DELETE_ACTION ?>">Delete selected</button>
            </div>
            <div class="col-sm-6" align="center">
                <h3><?php echo $f_myrow['f_name'].'&nbsp;'.$f_myrow['l_name']?>&nbsp;(<?php echo college_name($conn, $f_myrow['c_id'])?>)</h3>
            </div>
            <div class="col-sm-3"  align="right">
                <a href='faculty.php' class="btn btn-danger" >Back</a>
            </div>
        </div>

<?php
            $group_by = mysqli_query($conn, "SELECT distinct(branch_id) FROM subject_master where f_id='".$f_id."' ORDER BY branch_id");
            $run_one_time = true;
            if(mysqli_num_rows($group_by) > 0)
            {
                while($group_b_id = mysqli_fetch_array($group_by))
                {

                    echo '<div class="table-responsive">'.
                            '<table  class="table">'.
                                '<thead>'.
                                    '<th><center><b>'.branch_name($conn, $group_b_id['branch_id']).'</b></center></th>'.
                                '</thead>'.
                            '</table>'.
                          '</div>';
?>
                    <div class="table-responsive">
                        <table class="table table-striped table-sm" >
                            <thead class="thead-dark">
                                <tr>
                                    <th>
                                        <?php if($run_one_time) { ?>
                                            <input type='checkbox' name="select-all" id="select-all" />
                                        <?php $run_one_time = false;} ?>
                                    </th>
                                    <th><b>Subject Name</b></th>
                                    <th><b>Semester</b></th>
                                    <th><b>Batch</b></th>
                                    <th><b>Division</b></th>
                                    <th><b>Actions</b></th>
                                </tr>
                            </thead>
<?php       
                            $sql = "SELECT * FROM subject_master where f_id='".$f_id."' and branch_id='".$group_b_id['branch_id']."' order by batch_id asc, sem_id asc, division_id asc";
                            $result = mysqli_query($conn, $sql);
                            //lets make a loop and get all news from the database
                            $i=1;
                            if(mysqli_num_rows($result)>0)
                            {
                                while($myrow = mysqli_fetch_array($result))
                                {
                                    echo '<tr>';
                                    //echo "<td>".$i."</td>";$i++;
                                    echo "<td><input type='checkbox' name='id[ ]' value='".$myrow['sub_id']."' /></td>";
                                    echo "<td>".$myrow['sub_name']."</td>";
                                    echo "<td>".sem_name($conn, $myrow['sem_id'])."</td>";
                                    echo "<td>".batch_name($conn, $myrow['batch_id'])."</td>";
                                    echo "<td>".division_name($conn, $myrow['division_id'])."</td>";
                                    echo "<td>".
                                            '<a href="subject_actions.php?action='.UPDATE_ACTION.'&id='.$myrow['sub_id'].'" title="Edit subject" class="button"><i class="fas fa-edit fa-lg"></i></a> '.
                                            '<a href="subject_actions.php?action='.DELETE_ACTION.'&id='.$myrow['sub_id'].'&f_id='.$myrow['f_id'].'" title="Delete subject" class="delete-button button"><i class="fas fa-trash-alt fa-lg"></i></a>'.
                                        "</td>";
                                    echo '</tr>';
                                }
                            }
                            else
                            {
                                echo '<tr><td colspan=5 align=center>No record found!</td></tr>';
                            }
?>
                        </table>   
                    </div>
<?php
                }
            }
            else{
                echo '<div class="table-responsive"><table align=center><tr><th><b>No subject found!!</b></th></tr></table></div>';
            }
?>
    </form>
<?php
    include_once '../common_html_php_code/footer.php';
?>