<?php 
    include_once '../common_html_php_code/header.php';

    error_reporting( error_reporting() & ~E_NOTICE );
    $search_para_str = base64_decode( $_GET['str'] );
    $date_period_sql = base64_decode( $_GET['date_period'] ); 
    $sub_id = base64_decode( $_GET['sub_id'] );
    //echo $search_para_str;	  

    $res_date_period = mysqli_query($conn, $date_period_sql) or die(mysqli_error($conn));
    $date_period_str = "";
    while ($row = mysqli_fetch_array($res_date_period)) {
        $date_period_str = "(". date("d-m-Y", strtotime($row["from_date"])). " - ". date("d-m-Y", strtotime($row["to_date"])).")";
    }
    //echo $MAX_RATING;							
?>																						
                
    <div class="table-responsive">
        <table class="table table-striped table-sm" >
            <thead class="thead-dark">
                <tr>
                    <th><!--Roll No--></th>
                    <th><b>Faculty</b></th>
                    <th><b>Subject</b></th>
                    <th><b>College</b></th>
                    <th><b>Branch</b></th>
                    <th><b>Batch</b></th>
                    <th><b>Semester</b></th>
                    <th><b>Division</b></th>                                               
                </tr>
            </thead>
            <?php
                $sql_subj_details = "SELECT cm.c_name, sm.sub_id, sm.sub_name, bm.batch_name, brm.b_name, sem.sem_name, dm.division, fm.f_name, fm.l_name ".
                    "FROM subject_master as sm ".
                    "INNER JOIN faculty_master fm on fm.f_id = sm.f_id ".
                    "INNER JOIN batch_master bm on bm.batch_id = sm.batch_id ".
                    "INNER JOIN branch_master brm on brm.b_id = sm.branch_id ".
                    "INNER JOIN semester_master sem on sem.sem_id = sm.sem_id ".
                    "INNER JOIN division_master dm on dm.id = sm.division_id ". 
                    "INNER JOIN college_master cm on cm.c_id = fm.c_id ". 
                    "WHERE sub_id in ($sub_id) ";
                //echo $sql_subj_details;
                $res_subj_details = mysqli_query($conn, $sql_subj_details) or die("error in query");

                while ($row = mysqli_fetch_array($res_subj_details)) {
                    //echo $row["sub_name"];

                    $table_str = "<tr>";
                    $table_str .=  "<td>&nbsp;</td>";                                                
                    $table_str .=  "<td>".$row["f_name"]." ".$row["l_name"]."</td>";
                    $table_str .=  "<td>".$row["sub_name"]."</td>";
                    $table_str .=  "<td>".$row["c_name"]."</td>";
                    $table_str .=  "<td>".$row["b_name"]."</td>";
                    $table_str .=  "<td>".$row["batch_name"]."</td>";
                    $table_str .=  "<td>".$row["sem_name"]."</td>";
                    $table_str .=  "<td>".$row["division"]."</td>";
                    $table_str .= "</tr>";
                    echo $table_str;
                }                                                                                        
            ?>
        </table>
    </div>
    <div class="row">
        <div class="col-12">
            <div align="center"><h3>Rating matrix</h3></div>	
        </div>
    </div>
                    
<?php 

    $final_table_string_new = '<div class="table-responsive"><table class="table table-striped table-sm">';
    $final_table_string_new .= '<thead class="thead-dark"><tr><th><b>Rating</b></th>';
    for($i=1; $i<6; $i++)
    {
        $final_table_string_new .= "<th><b>".$i."'s</b></th>";
    }
    $final_table_string_new .= '</tr></thead>';		

    $analytic_array = array();

    function get_table_string($conn, $field_name, $search_para_str, $que_no, $analytic_array)
    {				
        global $analytic_array;
        global $MAX_RATING;
        $sql_query_q = 'select '.$field_name.', count(*) from feedback_master where ('. $search_para_str .') group by '.$field_name.' order by '.$field_name;				
        $res = mysqli_query($conn, $sql_query_q) or die(mysqli_error($conn));							  																		
        $data_array = array();			
        while($myrow=mysqli_fetch_array($res))
        {	  
            // $myrow["ans5"] = rating 
            // $myrow[1] = student count		  	  	
            $data_array[$myrow[$field_name]] = $myrow[1];		    		 		  		  		  					  						  						
        }													

        $que_table_string_new .= '<tr><td align="left"><b>'.que_one_word($conn, $que_no).'</b></td>';
        for($i=1; $i <= $MAX_RATING; $i++)
        {
            $val = ($data_array[$i] ? $data_array[$i] : 0 );
            $que_table_string_new .= '<td>'.$val. '</td>';
            $analytic_array[$i-1] += $val;					
        }
        $que_table_string_new .= '</tr>';

        return $que_table_string_new;
    }

    $final_table_string_new .= get_table_string($conn, 'ans1', $search_para_str, 1, $analytic_array);	
    $final_table_string_new .= get_table_string($conn, 'ans2', $search_para_str, 2, $analytic_array);	
    $final_table_string_new .= get_table_string($conn, 'ans3', $search_para_str, 3, $analytic_array);
    $final_table_string_new .= get_table_string($conn, 'ans4', $search_para_str, 4, $analytic_array);
    $final_table_string_new .= get_table_string($conn, 'ans5', $search_para_str, 5, $analytic_array);	
    $final_table_string_new .= get_table_string($conn, 'ans6', $search_para_str, 6, $analytic_array);
    $final_table_string_new .= get_table_string($conn, 'ans7', $search_para_str, 7, $analytic_array);
    $final_table_string_new .= get_table_string($conn, 'ans8', $search_para_str, 8, $analytic_array);
    $final_table_string_new .= get_table_string($conn, 'ans9', $search_para_str, 9, $analytic_array);	
    $final_table_string_new .= get_table_string($conn, 'ans9', $search_para_str, 10, $analytic_array);	

    $final_table_string_new .= '<tr class="thead-light"><th><b>Total</b></th>';
    $rating_n_analytic_value = 0;
    $total_of_rating = 0;
    for($i=0; $i < count($analytic_array); $i++)
    {
        $final_table_string_new .= '<td>'.$analytic_array[$i].' * '.$i.' = '.($i * $analytic_array[$i]).'</td>';
        //echo $i.' * '. $analytic_array[$i]. ' = '. ($i * $analytic_array[$i]).'<br/>';
        $rating_n_analytic_value += ($i * $analytic_array[$i]);
        $total_of_rating += $analytic_array[$i];
    }

    $analytic_result = ($rating_n_analytic_value / $total_of_rating);	
    $final_table_string_new .= '</tr>';	
    $final_table_string_new .= '<tr class="thead-dark"><th><b>Avg. Rating</b></th><th colspan="10"><b>'.($rating_n_analytic_value).'/'.$total_of_rating.' = '.number_format((float)$analytic_result, 2, '.', '').'</b></th></tr>';	

    $final_table_string_new .= '</table></div>';
    echo $final_table_string_new;
             
    include_once '../common_html_php_code/footer.php';
?>
<script language="javascript" type="text/javascript">
    function showTooltip(x, y, contents) {
        $('<div id="tooltip">' + contents + '</div>').css( {
            position: 'absolute',
            display: 'none',
            top: y + 5,
            left: x + 5,
            border: '1px solid #fdd',
            padding: '2px',
            'background-color': '#fee',
            opacity: 0.80
        }).appendTo("body").fadeIn(200);
    }
</script>