<?php 
    include_once '../common_html_php_code/header.php';
    
    if(isset($_POST['action']) && $_POST['action'] == DELETE_ACTION){
        delete_record($_POST, $conn, "college_master", "c_id", "college.php");
        exit();
    }
    
    ShowSessionMsg();
?>  
    <form method="post" class="form" action="<?php echo $_SERVER['REQUEST_URI'] ?>" id="id_form">
        <h2>
            <a href='college_actions.php' class="btn btn-primary" ><i class="fas fa-plus fa-sm"></i> Add college</a>
            <button type="submit" class="btn btn-danger" name="action" id="id_deletebtn" value="<?php echo DELETE_ACTION ?>">Delete selected</button>
        </h2>
        <div class="table-responsive">
            <table class="table table-striped table-sm">
                <thead class="thead-dark">
                    <tr>
                        <th><input type='checkbox' name="select-all" id="select-all" /></th>
                        <th><b>College Name</b></th>
                        <th><b>Actions</b></th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $result = mysqli_query($conn, "SELECT * FROM college_master ORDER BY c_id");
                        //$i=1;
                        if(mysqli_num_rows($result)>0)
                        {
                            while($myrow = mysqli_fetch_array($result))
                            {
                                echo '<tr>';
                                echo "<td><input type='checkbox' name='id[ ]' value='".$myrow['c_id']."' /></td>";
                                //$i++;
                                echo "<td>".$myrow['c_name']."</td>";
                                echo '<td>'.
                                        '<a href="college_actions.php?action='.UPDATE_ACTION.'&id='.$myrow['c_id'].'" title="Edit college" class="button"><i class="fas fa-edit fa-lg"></i></a> '.
                                        '<a href="college_actions.php?action='.DELETE_ACTION.'&id='.$myrow['c_id'].'" title="Delete college" class="delete-button button"><i class="fas fa-trash-alt fa-lg"></i></a>'.
                                    '</td>';
                                echo '</tr>';  

                            }//end of loop
                        }
                        else
                        {
                            echo '<tr><td colspan=2 align=center>No record found!</td></tr>';
                        }
                    ?>
                </tbody>
            </table>
        </div>
    </form>
<?php
    include_once '../common_html_php_code/footer.php';
?>