<?php
include("includes/db_config.php");
include("includes/common_functions.php");

function common_ternary_condition($request_data, $field_name){
    
    if(!array_key_exists($field_name, $request_data) || (gettype($request_data[$field_name]) == 'string' &&  $request_data[$field_name] == 'null')){
       return NULL;
    }
    
    return ((!isset($request_data[$field_name]) ? NULL : 
            (is_array($request_data[$field_name]) ? implode(",", array_map('intval', $request_data[$field_name])) : 
                $request_data[$field_name])));
}


function make_query_string($request_data){
    $query_string = "";

    $college_id = common_ternary_condition($request_data, 'college_id');
    $batch_id = common_ternary_condition($request_data, 'batch_id');
    $branch_id = common_ternary_condition($request_data, 'branch_id');
    $sem_id = common_ternary_condition($request_data, 'sem_id');
    $division_id = common_ternary_condition($request_data, 'division_id');
    $faculty_id = common_ternary_condition($request_data, 'f_id');
    
    if (isset($college_id) && !empty($college_id) && !is_null($college_id)) {//isset($college_id) && !empty($college_id)
        $temp_string = " fm.c_id in ( $college_id )";
        if(!empty($query_string)){
            $query_string .= " AND $temp_string";
        }
        else{
            $query_string .= $temp_string;
        }
    }
    
    if (isset($branch_id) && !empty($branch_id) && !is_null($branch_id)) {
        $temp_string = " sm.branch_id in ( $branch_id )";
        if(!empty($query_string)){
            $query_string .= " AND $temp_string ";
        }
        else{
            $query_string .= $temp_string;
        }
    }
    
    if(isset($batch_id) && !empty($batch_id) && !is_null($batch_id)){
        $temp_string = " sm.batch_id in ( $batch_id )";
        if(!empty($query_string)){
            $query_string .= " AND $temp_string ";
        }
        else{
            $query_string .= $temp_string;
        }
    }

    if (isset($sem_id) && !empty($sem_id) && !is_null($sem_id)) {
        $temp_string = " sm.sem_id in ( $sem_id )";
        if(!empty($query_string)){
            $query_string .= " AND $temp_string ";
        }
        else{
            $query_string .= $temp_string;
        }
    }

    if (isset($division_id) && !empty($division_id) && !is_null($division_id)) {
        $temp_string = " sm.division_id in ( $division_id )";
        if(!empty($query_string)){
            $query_string .= " AND $temp_string ";
        }
        else{
            $query_string .= $temp_string;
        }
    }

    if (isset($faculty_id) && !empty($faculty_id) && !is_null($faculty_id)) {
        $temp_string = " sm.f_id in ( $faculty_id ) ";
        if(!empty($query_string)){
            $query_string .= " AND $temp_string ";
        }
        else{
            $query_string .= $temp_string;
        }
    }
    
    return $query_string;
}

function common_filter_for_faculty_and_subject($request_data, $query_string, $conn){
    
    
    $college_id = common_ternary_condition($request_data, 'college_id');
    $batch_id = common_ternary_condition($request_data, 'batch_id');
    $branch_id = common_ternary_condition($request_data, 'branch_id');
    $sem_id = common_ternary_condition($request_data, 'sem_id');
    $division_id = common_ternary_condition($request_data, 'division_id');
    //$faculty_id = common_ternary_condition($request_data, 'f_id');
    
    $roll_no = $request_data['roll_no'];
    
    if (isset($roll_no) && $roll_no != 0) {
        $sql_filter = "select GROUP_CONCAT(sub_id SEPARATOR ',') as exclude_subject_ids from feedback_master where ".
            " roll_no='".$roll_no."' and college_id=".$college_id." and b_id=".$branch_id.
            " and sem_id=".$sem_id." and batch_id=".$batch_id." and division_id=".$division_id." and ".
            " feedback_no=1 ";
        //echo $sql_filter;
        $res = mysqli_query($conn, $sql_filter) or die(mysqli_error($conn));
        $data = mysqli_fetch_assoc($res);
        //mysqli_free_result($res);

        if(isset($query_string) && !empty($query_string) && isset($data['exclude_subject_ids']) && !empty($data['exclude_subject_ids'])){
            $temp_string = " sm.sub_id NOT IN  (".$data['exclude_subject_ids'].")";
            if(!empty($query_string)){
                $query_string .= " AND $temp_string ";
            }
            else{
                $query_string .= $temp_string;
            }
        }
    }
    return $query_string;
    
}
// for student feedback form - START
if(isset($_POST['get_faculty_list'])){
    
    $selected_faculty_id = $_POST['selected_faculty_name'];
    $query_string = make_query_string($_POST);
    
    $query_string = common_filter_for_faculty_and_subject($_POST, $query_string, $conn);
    
    $sql = "select DISTINCT fm.f_id, fm.f_name, fm.l_name from subject_master as sm inner join faculty_master fm on fm.f_id = sm.f_id where ".$query_string;
    $result_objs = mysqli_query($conn, $sql) or die("error in query - $sql");
    $str_select = "";
    if(mysqli_num_rows($result_objs) > 0){
        $str_select = "<select name='faculty_name' id='id_faculty_name' onchange='get_subjects()'  class=\"form-control\" >";
        $str_select .= "<option value=0>---select faculty---</option>";
        
        while($result_obj = mysqli_fetch_array($result_objs)){

            $selected_str = "";
            if((int)$selected_faculty_id == (int)$result_obj['f_id'])
                $selected_str = "selected";

            $str_select.= "<option value='".$result_obj['f_id']."' $selected_str>".$result_obj["f_name"]." ".$result_obj["l_name"]."</option>";
        }
        $str_select .= "</select>";
    }
    
    echo (empty($str_select)) ? "You have submitted feedback for all faculties for current semester." : $str_select;
        
}

if(isset($_POST['get_subject_list'])){
    $selected_subject_id = $_POST['selected_subject_name'];
    $query_string = make_query_string($_POST);
    $query_string = common_filter_for_faculty_and_subject($_POST, $query_string, $conn);
    
    $sql = "select sm.sub_id, sm.sub_name from subject_master as sm inner join faculty_master fm on fm.f_id = sm.f_id where ".$query_string;
    $result_objs = mysqli_query($conn, $sql) or die("error in query");
    $str_select = "";
    if(mysqli_num_rows($result_objs) > 0){
        $str_select = "<select name='subject_name' id='id_subject_name' class=\"form-control\" >";
        while($result_obj = mysqli_fetch_array($result_objs)){

            $selected_str = "";
            if((int)$selected_subject_id == (int)$result_obj['sub_id'])
                $selected_str = "selected";

            $str_select.= "<option value='".$result_obj['sub_id']."' $selected_str>".$result_obj["sub_name"]."</option>";
        }
        $str_select .= "</select>";
    }
    echo $str_select;
}
// for student feedback form - END

// for admin feedback report - START
if(isset($_POST['get_all_faculty_list'])){
    
    $query_string = make_query_string($_POST);
    
    $sql = "select DISTINCT fm.f_id, fm.f_name, fm.l_name from subject_master as sm inner join faculty_master fm on fm.f_id = sm.f_id where ".$query_string;
    $result_objs = mysqli_query($conn, $sql) or die("error in query - $sql");
    $str_select = "";
    if(mysqli_num_rows($result_objs) > 0){
        $selected_faculty_id = explode(',', $_POST['selected_faculty_name']);
        $select_para = (isset($_POST['callfrom']) && $_POST['callfrom'] == 1) ? 
                " name='faculty_name[ ]' multiple size='5' onchange='get_all_subjects()'" : "name='faculty_name' ";
        
        $str_select = "<select class=\"form-control\" id='id_faculty_name' $select_para>";
        //$str_select .= "<option value=0>---select faculty---</option>";
        
        while($result_obj = mysqli_fetch_array($result_objs)){

            $selected_str = "";
            if(in_array((int)$result_obj['f_id'], $selected_faculty_id))
                $selected_str = "selected";

            $str_select.= "<option value='".$result_obj['f_id']."' $selected_str>".$result_obj["f_name"]." ".$result_obj["l_name"]."</option>";
        }
        $str_select .= "</select>";
    }
    echo $str_select;
}

if(isset($_POST['get_all_subject_list'])){
    $query_string = make_query_string($_POST);
    $branches = array();
    
    $sql = "SELECT sm.sub_id, sm.sub_name, bm.batch_name, brm.b_id, brm.b_name, sem.sem_name, dm.division ".
           "FROM subject_master as sm ".
           "INNER JOIN faculty_master fm on fm.f_id = sm.f_id ".
           "INNER JOIN batch_master bm on bm.batch_id = sm.batch_id ".
           "INNER JOIN branch_master brm on brm.b_id = sm.branch_id ".
           "INNER JOIN semester_master sem on sem.sem_id = sm.sem_id ".
           "INNER JOIN division_master dm on dm.id = sm.division_id ".
           "WHERE ".$query_string . " order by sm.branch_id ASC, sm.batch_id ASC ";
    $result_objs = mysqli_query($conn, $sql) or die("error in query");
    $str_select = "";
    
    if(mysqli_num_rows($result_objs) > 0){
        $selected_subjects = explode(',', $_POST['selected_subject_name']);
        
        $str_select = "<select name='subject_name[ ]' id='id_subject_name' multiple size='5' class=\"form-control\">";
        $last_branch = -1; 
        $sub_count = 0;
       
        while($result_obj = mysqli_fetch_array($result_objs)){
            
            $current_branch = $result_obj['b_id'];
            
            if($last_branch != $result_obj['b_id']){
                $last_branch = $result_obj['b_id'];               
                $str_select.= "<optgroup label='".$result_obj["b_name"]."'>";
                $sub_count++;                
            }
            else{
                if($sub_count > 1 && $last_branch != $result_obj['b_id']){                                        
                    $sub_count = 0;
                    $str_select.= "</optgroup>";
                }
            }

            $selected_str = "";
            if(in_array((int)$result_obj['sub_id'], $selected_subjects))          
                $selected_str = "selected";
            
            $str_select.= "<option value='".$result_obj['sub_id']."' $selected_str>".
                $result_obj["sub_name"]. " [" .$result_obj["batch_name"]."] [".$result_obj["sem_name"]."] [".
                $result_obj["division"]."]</option>";                                   
        }
        $str_select .= "</select>";
    }
    echo ($str_select) ? $str_select: "No subject found!!";
}
// for admin feedback report - START

if(isset($_POST['get_branch_list'])){
    
    $college_id = common_ternary_condition($_POST, 'college_id');
    
    $sql = "select b_id, b_name from branch_master where college_id in (".$college_id.")";
    $result_objs = mysqli_query($conn, $sql) or die("error in query");
    $str_select = "";
    
    if(mysqli_num_rows($result_objs) > 0){
        $selected_branch_id = explode(',', $_POST['selected_branch_name']);
        
        $select_para = (isset($_POST['callfrom']) && $_POST['callfrom'] == 1) ? 
                " name='branch_name[ ]' multiple size='5' onchange='return branch_change()'" : "name='branch_name' ";
        
        $str_select = "<select id='id_branch_name' class=\"form-control\" $select_para>";
        //$str_select .= "<option value=0>---select branch---</option>";
        while($result_obj = mysqli_fetch_array($result_objs)){

            $selected_str = "";
            if(in_array((int)$result_obj['b_id'], $selected_branch_id))
                $selected_str = "selected";

            $str_select.= "<option value='".$result_obj['b_id']."' $selected_str>".$result_obj["b_name"]."</option>";
        }
        $str_select .= "</select>";
    }
    echo $str_select;
}
?>
