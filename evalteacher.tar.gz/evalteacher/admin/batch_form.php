<h1 class="h2"><?php echo ($action == UPDATE_ACTION) ? UPDATE_ACTION_TEXT : ADD_ACTION_TEXT ?> Batch</h1>  
<form method="post" class="form" action="<?php echo $_SERVER['REQUEST_URI'] ?>" name="edit_batch" onsubmit="return chkForm();">
    <?php if ($action == UPDATE_ACTION){ ?>
        <input type="hidden" name="batch_id" value="<?php echo $batch_id ?>" />
    <?php } ?>
    <input type="hidden" value="1" name="feedback_no" />
    <div class="form-group">
        <label class="control-label col-sm-2" for="batch">Batch Name</label>
        <div class="col-sm-4">
            <input type="text" class="form-control" id="id_batch_name" name="batch_name" placeholder="Enter batch name" value="<?php echo $batch_name ?>"/>
        </div>
    </div>
    <div class="form-group">
        <div class="col-sm-offset-2 col-sm-4">
            <button type="submit" class="btn btn-default" name="submit" id="id_submit" value="<?php echo $action ?>"><?php echo ($action == UPDATE_ACTION) ? UPDATE_ACTION_TEXT : ADD_ACTION_TEXT ?></button>
            <a href='batch.php' class="btn btn-danger">Back</a>
        </div>
    </div>
</form>