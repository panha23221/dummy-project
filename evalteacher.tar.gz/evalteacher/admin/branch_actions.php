<?php 
    include_once '../common_html_php_code/header.php';
    $action = (int)((isset($_GET['action'])) ? sanitize($conn, $_GET['action']): ADD_ACTION);
    
    $branch_name = '';
    $branch_id = '';
    $college_id = '';
    
    if($action == DELETE_ACTION){    
        delete_record($_GET, $conn, "branch_master", "b_id", "branch.php");
        exit();
    }
    else if($action == UPDATE_ACTION){
        $branch_id = sanitize($conn, $_GET['id']);
        $result = mysqli_query($conn, "SELECT * FROM branch_master WHERE b_id='$branch_id' ");
        while($myrow = mysqli_fetch_assoc($result))
        {
            $branch_id = $myrow['b_id'];
            $branch_name = $myrow["b_name"];
            $college_id = $myrow["college_id"];
        }
    }
    
    if(isset($_POST['submit']))
    {
        $branch_id = array_key_exists('branch_id', $_POST) ? sanitize($conn, $_POST['branch_id']) : '';
        $branch_name = array_key_exists('branch_name', $_POST) ? sanitize($conn, $_POST['branch_name']) : '';
        $college_id = array_key_exists('college_id', $_POST) ? sanitize($conn, $_POST['college_id']) : '';
        $action = sanitize($conn, $_POST['submit']);
        
        if(empty($branch_name) || empty($college_id) || empty($college_id) || $college_id <= 0){
            $_SESSION['error_msg'] = "Please enter branch name and select college.";
        }
        else{
            if($action == ADD_ACTION){
                //check duplication
                $dup = "select b_id from branch_master where b_name='$branch_name' and college_id=$college_id";                            
                $dup_res = mysqli_query($conn, $dup) or die(mysqli_error($conn));
                if(mysqli_num_rows($dup_res) >= 1)
                {            
                    $_SESSION['error_msg'] = "Branch name is already available in database. Please enter another name or select another college";            
                }
                else
                {
                    //run the query which adds the data gathered from the form into the database
                    mysqli_query($conn, "INSERT INTO branch_master (b_name, college_id) VALUES ('$branch_name', $college_id)");
                    //print success message.
                    $_SESSION['success_msg'] = "Branch is added Successfully!";                
                    header( "refresh:0;url=branch.php" );
                    exit();
                }
                
            }
            else if($action == UPDATE_ACTION){
                //check duplication
                $dup="select * from branch_master where b_name='$branch_name' and college_id = $college_id and b_id!=".$branch_id;
                $dup_res=mysqli_query($conn, $dup) or die(mysqli_error($conn));
                if(mysqli_num_rows($dup_res) == 1)
                {
                    $_SESSION['error_msg'] = "Branch name is already available in branch table under same college.";            
                }
                else
                {                                                        
                    $result = mysqli_query($conn, "UPDATE branch_master SET b_name='$branch_name', college_id=$college_id WHERE b_id='$branch_id'");
                    $_SESSION['success_msg'] = "Branch is updated Successfully!";                        
                    header( "refresh:0;url=branch.php" );
                    exit();
                }
            }
        }
    }
    
    ShowSessionMsg();
    include_once 'branch_form.php';
    include_once '../common_html_php_code/footer.php';
?>
               
<script language="javascript" type="text/javascript">
    function chkForm()
    {
        if ( $("#id_branch_name").val().length < 1 )
        {
            alert("Enter Branch Name");	
            $("#id_branch_name").focus();		
            return false;
        }
        if ($("#id_college_id").val() == 0 )
        {
            alert("Select College Name");
            $("#id_college_id").focus();
            return false;
        }      
    }
</script>