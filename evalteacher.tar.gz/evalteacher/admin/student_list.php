<?php 
    include_once '../common_html_php_code/header.php';

    if(isset($_GET['reset']) && $_GET['reset']==true && isset($_GET['std_id']))
    {
        $std_id = sanitize($conn, $_GET['std_id']);
        $value = md5($std_id);
        mysqli_query($conn, "UPDATE student_master SET passwd='$value' WHERE roll_no='".$std_id."'");		
        $_SESSION['success_msg'] = "<b>Password successfully reset for ".$std_id."!</b>";
    }
    
    if(isset($_GET['delete']) && $_GET['delete']==true && isset($_GET['std_id']))
    {
        $std_id = sanitize($conn, $_GET['std_id']);
        mysqli_query($conn, "DELETE FROM student_master WHERE roll_no='".$std_id."'");	
        $_SESSION['success_msg'] = "<b>".$std_id." is deleted successfully!</b>";
    }

    if(isset($_POST['delete_selected']) && isset($_POST['roll_ids'])){

        $roll_ids = sanitize($conn, $_POST['roll_ids']);
        $delete_sql = "DELETE from student_master where roll_no in ('".implode("','", $roll_ids)."')";
        mysqli_query($conn, $delete_sql) or die(mysqli_error('error in query'));
        $_SESSION['success_msg'] = "<b>['".implode("' , '", $roll_ids)."'] are deleted successfully!</b>";
    }

    $student_id_type = 2;
    $student_id = '';
    //print_r($_SESSION);

    function get_query_str($student_id, $student_id_type, $batch_id, $branch_id, $sem_id, $division_id, $college_id)
    {
        $query_string = '';
        if(!empty($student_id) && $student_id_type == 1)
        {
            $query_string.= "( roll_no LIKE '%".$student_id."%' OR first_name LIKE '%".$student_id."%' OR last_name LIKE '%".$student_id."%' )";		
        }
        if(!empty($student_id) && $student_id_type == 2)
        {
            $query_string.= "( roll_no='".$student_id."' OR first_name = '".$student_id."' OR last_name = '".$student_id."' )";		
        }
        if(!empty($student_id) && $student_id_type == 3)
        {
            $query_string.= "( roll_no LIKE '".$student_id."%' OR first_name LIKE '".$student_id."%' OR last_name LIKE '".$student_id."%' )";		
        }
        if(!empty($student_id) && $student_id_type == 4)
        {
            $query_string.= "( roll_no LIKE '%".$student_id."' OR first_name LIKE '%".$student_id."' OR last_name LIKE '%".$student_id."' )";		
        }
        if(!empty($college_id)){
            $temp_query_string =" college_id = '".$college_id."'";
            if(!empty($query_string))
                $query_string.=" AND $temp_query_string";
            else
                $query_string.= $temp_query_string;
        }
        if(!empty($batch_id)){
            $temp_query_string.= " AND batch_id = '".$batch_id."'";
            if(!empty($query_string))
                $query_string.=" AND $temp_query_string";
            else
                $query_string.= $temp_query_string;
        }
        if(!empty($branch_id)){
            $temp_query_string.=" AND branch_id = '".$branch_id."'";
            if(!empty($query_string))
                $query_string.=" AND $temp_query_string";
            else
                $query_string.= $temp_query_string;
        }
        if(!empty($sem_id)){
            $temp_query_string.=" AND sem_id = '".$sem_id."'";
            if(!empty($query_string))
                $query_string.=" AND $temp_query_string";
            else
                $query_string.= $temp_query_string;
        }
        if(!empty($division_id)){
            $temp_query_string.=" AND division_id = '".$division_id."'";
            if(!empty($query_string))
                $query_string.=" AND $temp_query_string";
            else
                $query_string.= $temp_query_string;
        }                                
        return $query_string;
    }
    
    //$slq_search="select * from feedback_master order by feed_date asc";
    $sql_search = 'select * from student_master where roll_no=0';
    if(isset($_SESSION['student_id_type']) && isset($_SESSION['student_id_val']) && isset($_SESSION['student_batch_id_val']) && $_SESSION['student_branch_id_val'] && $_SESSION['student_sem_id_val'] && $_SESSION['student_division_id_val'])
    {
        $query_string = get_query_str(
            $_SESSION['student_id_val'], $_SESSION['student_id_type'], $_SESSION['student_batch_id_val'], 
            $_SESSION['student_branch_id_val'], $_SESSION['student_sem_id_val'], $_SESSION['student_division_id_val'], 
            $_SESSION['student_college_id_val']);
        //print_r($query_string);
        if(!empty($query_string)){ 
            $sql_search = "select * from student_master where (".$query_string.")";
        }					
    }
    $res_search = mysqli_query($conn, $sql_search) or die(mysqli_error($conn));

    if(isset($_POST['submit']))
    {	
        $college_id = sanitize($conn, $_POST['college_name']);
        $batch_id = sanitize($conn, $_POST['batch_name']);
        $branch_id = sanitize($conn, isset($_POST['branch_name']) ? $_POST['branch_name'] : 0 );
        $sem_id = sanitize($conn, $_POST['sem_name']);
        $division_id = sanitize($conn, $_POST['division_name']);
        $student_id_type = sanitize($conn, $_POST['student_id_type']);
        $student_id = sanitize($conn, $_POST['student_id']);

        $_SESSION['student_id_type'] = 	$student_id_type;
        $_SESSION['student_id_val'] = $student_id;
        $_SESSION['student_batch_id_val'] = $batch_id;
        $_SESSION['student_branch_id_val'] = $branch_id;
        $_SESSION['student_sem_id_val'] = $sem_id;
        $_SESSION['student_division_id_val'] = $division_id;
        $_SESSION['student_college_id_val'] = $college_id;

        $query_string = get_query_str($student_id, $student_id_type, $batch_id, $branch_id, $sem_id, $division_id, $college_id);

        if(!empty($query_string)){ 
            $sql_search = "select * from student_master where (".$query_string.")";                    
        }
        else{
            $sql_search = "select * from student_master";
        }
        //echo $sql_search;
        $res_search = mysqli_query($conn, $sql_search) or die(mysqli_error('query error'));	
    }
    
    ShowSessionMsg();
?>
    <form name="std_list_form" id="id_std_list_form" action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post" enctype="multipart/form-data">
        <div class="row">
            <div class="col-2">
                <label><b>College</b></label>
                <?php
                    $sel_college = "select c_id, c_name from college_master";
                    $res_college = mysqli_query($conn, $sel_college) or die(mysqli_error($conn));

                    while($college_combo=mysqli_fetch_array($res_college))
                    {							
                        $college_array[] = array('id' => $college_combo['c_id'],
                                                 'text' => $college_combo['c_name']);								  
                    }
                    if(isset($college_name))
                        $default = $college_name;
                    else
                        $default = !empty($_SESSION['student_college_id_val']) ? $_SESSION['student_college_id_val']:'';
                    echo tep_draw_pull_down_menu('college_name', $college_array, $default,' id="id_college_name" class="form-control" ');
                ?>
            </div>
            <div class="col-3">
                <label><b>Branch</b></label>
                <div id="id_branch_dropdown_div"></div>
            </div>
            <div class="col-2">
                <label><b>Batch</b></label>
                <?php
                    $sel_batch = "select batch_id, batch_name from batch_master";
                    $res_batch = mysqli_query($conn, $sel_batch) or die(mysqli_error($conn));

                    while($batch_combo=mysqli_fetch_array($res_batch))
                    {							
                        $batch_array[] = array('id' => $batch_combo['batch_id'],
                                               'text' => $batch_combo['batch_name']);								  
                    }
                    if(isset($batch_name))
                        $default = $batch_name;
                    else
                        $default = !empty($_SESSION['student_batch_id_val']) ? $_SESSION['student_batch_id_val']:'';
                    echo tep_draw_pull_down_menu('batch_name', $batch_array, $default,' id="id_batch_name" class="form-control" ');
                ?>
            </div>
            <div class="col-2">
                <label><b>Semester</b></label>
                <?php
                    $sel_sem = "select sem_id, sem_name from semester_master";
                    $res_sem = mysqli_query($conn, $sel_sem) or die(mysqli_error($conn));

                    while($sem_combo=mysqli_fetch_array($res_sem))
                    {							
                        $sem_array[] = array('id' => $sem_combo['sem_id'],
                                             'text' => $sem_combo['sem_name']);								  
                    }
                    if(isset($sem_name))
                        $default = $sem_name;
                    else
                        $default = !empty($_SESSION['student_sem_id_val']) ? $_SESSION['student_sem_id_val']:'';
                    echo tep_draw_pull_down_menu('sem_name', $sem_array, $default, ' id="id_sem_name" class="form-control" ');
                ?>
            </div>
            <div class="col-2">
                <label><b>Division</b></label>
                <?php
                    $sel_division = "select id, division from division_master";
                    $res_division = mysqli_query($conn, $sel_division) or die(mysqli_error($conn));

                    while($division_combo = mysqli_fetch_array($res_division))
                    {							
                        $division_array[] = array('id' => $division_combo['id'],
                                                  'text' => $division_combo['division']);
                    }
                    if(isset($division_name))
                            $default = $division_name;
                    else
                            $default = !empty($_SESSION['student_division_id_val']) ? $_SESSION['student_division_id_val']:'';
                    echo tep_draw_pull_down_menu('division_name', $division_array, $default,' id="id_division_name" class="form-control"');
                ?> 
            </div>
        </div>
        <div class="row">
            <div class="col-2">
                <label><b>Student Detail</b></label>
                <?php 
                    if(isset($_SESSION['student_id_val'])){ 
                        $student_id_val = $_SESSION['student_id_val'];
                    }
                    else{
                        $student_id_val = '';
                    }
                    $student_id_type_1 = '';
                    $student_id_type_2 = 'checked="checked"';
                    $student_id_type_3 = '';
                    $student_id_type_4 = '';
                    if(isset($_SESSION['student_id_type'])){ 
                        if($_SESSION['student_id_type'] == 1){
                            $student_id_type_1 = 'checked="checked"';
                            $student_id_type_2 = '';
                            $student_id_type_3 = '';
                            $student_id_type_4 = '';
                        }
                        if($_SESSION['student_id_type'] == 2){
                            $student_id_type_1 = '';
                            $student_id_type_2 = 'checked="checked"';
                            $student_id_type_3 = '';
                            $student_id_type_4 = '';
                        }
                        if($_SESSION['student_id_type'] == 3){
                            $student_id_type_1 = '';
                            $student_id_type_2 = '';
                            $student_id_type_3 = 'checked="checked"';
                            $student_id_type_4 = '';
                        }
                        if($_SESSION['student_id_type'] == 4){
                            $student_id_type_1 = '';
                            $student_id_type_2 = '';
                            $student_id_type_3 = '';
                            $student_id_type_4 = 'checked="checked"';
                        }
                    }			

                ?>
                <input typpe="text" name="student_id" id="id_student" class="form-control" value="<?php echo $student_id_val;?>" />
            </div>
            <div class="col-6 form-check-inline">
                
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="student_id_type" value="1" <?php echo $student_id_type_1;?> />
                    <label class="form-check-label"> contain </label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="student_id_type" value="2" <?php echo $student_id_type_2;?>  />
                    <label class="form-check-label"> Equal </label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="student_id_type" value="3" <?php echo $student_id_type_3;?> />
                    <label class="form-check-label"> Start with </label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="student_id_type" value="4" <?php echo $student_id_type_4;?> />
                    <label class="form-check-label"> Ends with </label>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-4">
                <input class="btn btn-blue" type="submit" name="submit" value="Submit" id="id_submit" /> 
                <input class="btn btn-danger" type="submit" name="delete_selected" value="Delete selected" id="id_delete" />
            </div>
        </div>
        

        <div class="row">
            <div class="col-12"><b>Number of Records :</b> <?php echo mysqli_num_rows($res_search); ?></div>
        </div>

        <div class="table-responsive">
            <table class="table table-striped table-sm">
                <thead class="thead-dark">
                    <tr>
                        <th><input type='checkbox' name="select-all" id="select-all" /></th>
                        <th><b>Roll No</b></th>
                        <th><b>Student Name</b></th>
                        <th><b>Email</b></th>	
                        <th><b>Action</b></th>
                    </tr>
                </thead>

                <?php
                    if(mysqli_num_rows($res_search)!=0)
                    {			
                        $i=0; 
                        while($myrow = mysqli_fetch_array($res_search))
                        {
                            //now print the results:
                            echo '<tr>';
                            echo "<td><input type='checkbox' name='roll_ids[]' value='".$myrow['roll_no']."' /></td>";
                            echo "<td>".$myrow['roll_no']."</td>";
                            $i++;
                            echo "<td>".$myrow['first_name'].' '.$myrow['last_name']."</td>";
                            echo "<td>".$myrow['email_id']."</td>";			  			   
                            echo "<td>".
                                    "<a href=\"student_list.php?std_id=$myrow[roll_no]&reset=true\" title='Reset password'><i class=\"fas fa-retweet fa-lg\"></i></a> ".
                                    "<a href=\"student_list.php?std_id=$myrow[roll_no]&delete=true\" title='Delete user' class=\"delete-button\" ><i class=\"fas fa-trash-alt fa-lg\"></i></a>".
                                "</td>";
                            echo '</tr>';
                        }									
                    }
                    else
                    {
                        echo "<tr>";
                        echo "<td align=center colspan=5>No Record Found!</td></tr>";
                    }
                ?>
            </table>
        </div>
    </form>
<?php
    include_once '../common_html_php_code/footer.php';
?>
<script language="javascript" type="text/javascript">
	
    $(function(){
    	$("#id_submit").click(function() {
            var error = false;
            if ($("#id_batch_name").val() <= 0 && $("#id_student").val() == '')
            {
                alert("Select batch or enter student detail like id,name,email.");
                error = true;
            }			
            if (!error) {
                    $("#id_std_list_form").submit();
            }else{
                    return false;
            }
    });

    $("#id_delete").click(function() {
        var error = false;
        if ($("#id_std_list_form input:checkbox:checked").length > 0)
        {}
        else
        {
            alert("Select atlest one student id to delete.");
            error = true;
        }
        if (!error) {
            if(confirm("Are you sure you want to delete student ids?")){
                $("#id_std_list_form").submit();
            }

        }else{
            return false;
        }
    });

    
    $( "#id_college_name" ).change(function() { 
        get_branch_list();
        return false;
    });
});

</script>

<?php
    if (isset($_POST['submit']) && isset($branch_id)) {
?>
    <script type='text/javascript'>
        get_branch_list('<?php echo $branch_id ?>'); 
    </script>
<?php
    }
?>

