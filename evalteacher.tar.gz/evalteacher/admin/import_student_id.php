<?php
    include_once '../common_html_php_code/header.php';

    function number_pad($number, $n)
    {
        return str_pad((int) $number, $n, "0", STR_PAD_LEFT);
    }

    if (isset($_POST['import'])) {
        
        $college_id  = sanitize($conn, $_POST['college_name']);
        $batch_id    = sanitize($conn, $_POST['batch_name']);
        $branch_id   = sanitize($conn, $_POST['branch_name']);
        $sem_id      = sanitize($conn, $_POST['sem_name']);
        $division_id = sanitize($conn, $_POST['division_name']);

        $filename = $_FILES["file"]["name"];
        $ext      = substr($filename, strrpos($filename, "."), (strlen($filename) - strrpos($filename, ".")));

        if ($ext == ".csv") {

            $targetPath = 'uploads/' . $_FILES['file']['name'];
            move_uploaded_file($_FILES['file']['tmp_name'], $targetPath);

            $alreadyExistsRollNo = array();
            $bulkInsert          = array();
            $errorInIds          = array();

            $file    = fopen($targetPath, "r");
            $isFirst = true;
            
            while (($Row = fgetcsv($file, ",")) !== false) {
                if ($isFirst) {
                    $isFirst = false;
                    continue;
                }

                $roll_no = "";
                $name    = "";
                if (isset($Row[0]) && isset($Row[1])) {

                    $roll_no = sanitize($conn, $Row[0]);
                    $fname   = sanitize($conn, $Row[1]);
                    $lname   = sanitize($conn, $Row[2]);
                    $semail  = sanitize($conn, $Row[3]);

                    if (!empty($roll_no) && !empty($fname)) {

                        if (preg_match("/^[0-9]{3}[A-Za-z]{1,2}[0-9]{5}$/", $roll_no) === 0) {
                            array_push($errorInIds, $roll_no);
                        } else {

                            $check_dup        = "select * from student_master where roll_no='$roll_no'";
                            $check_dup_result = mysqli_query($conn, $check_dup) or die(mysqli_error($conn));
                            if (mysqli_num_rows($check_dup_result) > 0) {
                                array_push($alreadyExistsRollNo, $roll_no);
                            } else {
                                array_push(
                                    $bulkInsert, 
                                    '("' . $roll_no . '", "' . $fname . '", "'.$lname.'", "'.$semail.'", md5("' . $roll_no . '"), "'.$college_id.'", "' . $batch_id . '", "' . $branch_id . '", "' . $sem_id . '", "' . $division_id . '")');
                            }
                        }
                    }
                }

            }
            fclose($file);

            $err_msg = "";
            if (!empty($errorInIds)) {
                $err_msg .= "<br/>Student IDs [" . implode(", ", $errorInIds) . "] are incorrect format. It should be like 573CS18001. Please fix them in excel file & re-upload.<br/>";
            }
            if (!empty($alreadyExistsRollNo)) {
                $err_msg .= "<br/>Student IDs [" . implode(", ", $alreadyExistsRollNo) . "] already exits.<br/>";
            }
            if (!empty($bulkInsert)) {
                foreach (array_chunk($bulkInsert, 100) as $bulk) {
                    $query = "insert into student_master(roll_no, first_name, last_name, email_id, passwd, college_id, batch_id, branch_id, sem_id, division_id) VALUES " . implode(",", $bulk);
                    mysqli_query($conn, $query) or die(mysqli_error($conn));
                }
                $_SESSION['success_msg'] = "CSV Data Imported into the database successfully, please check Student List link!";
            }
            else{$_SESSION['error_msg'] = $err_msg;}

            if (file_exists($targetPath)) {unlink($targetPath);}
        } else {
            $_SESSION['error_msg'] = "Invalid File Type. Upload CSV File only.";
        }
        
    } //end of if($submit).
    ShowSessionMsg();
?>
<form name="std_id_form" id="id_std_id_form" action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post" enctype="multipart/form-data">
    <div class="row">
        <div class="col-2">
            <label><b>College</b></label>
            <?php
                $sel_college = "select c_id, c_name from college_master";
                $res_college = mysqli_query($conn, $sel_college) or die(mysqli_error($conn));

                while ($college_combo = mysqli_fetch_array($res_college)) {
                    $college_array[] = array('id' => $college_combo['c_id'],
                                             'text' => $college_combo['c_name']);
                }
                if (isset($college_name)) { 
                    $default = $college_name;
                } else {
                    $default = '';
                }

                echo tep_draw_pull_down_menu('college_name', $college_array, $default, ' id="id_college_name" class="form-control"');
            ?>
        </div>
        <div class="col-3">
            <label><b>Branch</b></label>
            <div id="id_branch_dropdown_div"></div>
        </div>
        <div class="col-2">
            <label><b>Batch</b></label>
            <?php
                $sel_batch = "select batch_id, batch_name from batch_master";
                $res_batch = mysqli_query($conn, $sel_batch) or die(mysqli_error($conn));

                while ($batch_combo = mysqli_fetch_array($res_batch)) {
                    $batch_array[] = array('id' => $batch_combo['batch_id'],
                                           'text' => $batch_combo['batch_name']);
                }
                if (isset($batch_name)) {
                    $default = $batch_name;
                } else {
                    $default = '';
                }

                echo tep_draw_pull_down_menu('batch_name', $batch_array, $default, ' id="id_batch_name" class="form-control" ');
            ?>
        </div>
        <div class="col-2">
            <label><b>Semester</b></label>
            <?php
                $sel_sem = "select sem_id, sem_name from semester_master";
                $res_sem = mysqli_query($conn, $sel_sem) or die(mysqli_error($conn));

                while ($sem_combo = mysqli_fetch_array($res_sem)) {
                    $sem_array[] = array('id' => $sem_combo['sem_id'],
                                         'text' => $sem_combo['sem_name']);
                }
                if (isset($sem_name)) {
                    $default = $sem_name;
                } else {
                    $default = '';
                }
                echo tep_draw_pull_down_menu('sem_name', $sem_array, $default, ' id="id_sem_name" class="form-control" ');
            ?>
        </div>
        <div class="col-2">
            <label><b>Division</b></label>
            <?php
                $sel_division = "select id, division from division_master";
                $res_division = mysqli_query($conn, $sel_division) or die(mysqli_error($conn));

                while ($division_combo = mysqli_fetch_array($res_division)) {
                    $division_array[] = array('id' => $division_combo['id'],
                                              'text' => $division_combo['division']);
                }
                if (isset($division_name)) {
                    $default = $division_name;
                } else {
                    $default = '';
                }
                echo tep_draw_pull_down_menu('division_name', $division_array, $default, ' id="id_division_name" class="form-control" ');
            ?>
        </div>
    </div>
    <div class="row">
        <div class="col-4">
            <label>Upload CSV</label>
            <input type="file" name="file" id="id_file" accept=".csv" class="form-control-file" />
            <small id="passwordHelpBlock" class="form-text text-muted">
                <a href="database_backup/CSE-student.csv" target="_blank" class="">(Download sample csv)</a>
            </small>
            
        </div>
    </div>
    <div class="row">
        <div class="col-4">
            <input class="btn btn-blue" type="submit" name="import" value="Import" id="id_import" />
        </div>
    </div>
</form>
 
<?php
    include_once '../common_html_php_code/footer.php';
?>

<script language="javascript" type="text/javascript">
    
    $(function(){
    	function hasExtension(inputID, exts) {
            var fileName = document.getElementById(inputID).value;
            return (new RegExp('(' + exts.join('|').replace(/\./g, '\\.') + ')$')).test(fileName);
        }

    	$("#id_import").click(function() {
            var error = false;
            if ($("#id_batch_name").val() <= 0){
                alert("Select batch.");
                error = true;
            }
            else if ($("#id_branch_name").val() <= 0){
                alert("Select branch.");
                error = true;
            }
            else if ($("#id_sem_name").val() <= 0){
                alert("Select semester.");
                error = true;
            }
            else if ($("#id_division_name").val() <= 0){
                alert("Select division.");
                error = true;
            }
            else if($("#id_file").val() == ''){
                alert("Upload excel file.");
                error = true;
            }
            else if (!hasExtension('id_file', ['.csv'])) {
                alert("Please upload only CSV extension file.");
                error = true;
            }
            if (!error) {
                $("#id_std_id_form").submit();
            }else{
                return false;
            }
    	});
        $( "#id_college_name" ).change(function() { 
            get_branch_list();
            return false;
        });
    });
</script>
