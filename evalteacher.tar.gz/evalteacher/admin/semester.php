<?php 
    include_once '../common_html_php_code/header.php';
    
    if(isset($_POST['action']) && $_POST['action'] == DELETE_ACTION){
        delete_record($_POST, $conn, "semester_master", "sem_id", "semester.php");
        exit();
    }
    
    ShowSessionMsg();
?>            
    <form method="post" class="form" action="<?php echo $_SERVER['REQUEST_URI'] ?>" id="id_form">
        <h2>
            <a href='semester_actions.php' class="btn btn-primary" ><i class="fas fa-plus fa-sm"></i> Add semester</a>
            <button type="submit" class="btn btn-danger" name="action" id="id_deletebtn" value="<?php echo DELETE_ACTION ?>">Delete selected</button>
        </h2>
        <div class="table-responsive">
            <table class="table table-striped table-sm">
                <thead class="thead-dark">
                    <tr>
                        <th><input type='checkbox' name="select-all" id="select-all" /></th>
                        <th scope="col" ><b>Semester Name</b></th>
                        <th scope="col" ><b>Actions</b></th>
                    </tr>
                </thead>

                <?php
                    $result = mysqli_query($conn, "SELECT * FROM semester_master ORDER BY sem_id");                
                    //$i=1;
                    if(mysqli_num_rows($result)>0)
                    {
                        while($myrow = mysqli_fetch_array($result))
                        {
                            echo '<tr>';
                            //echo "<td align=center>".$i."</td>";$i++;
                            echo "<td><input type='checkbox' name='id[ ]' value='".$myrow['sem_id']."' /></td>";
                            echo "<td>".$myrow['sem_name']."</td>";
                            echo "<td>".
                                    '<a href="semester_actions.php?action='.UPDATE_ACTION.'&id='.$myrow['sem_id'].'" title="Edit semester" class="button"><i class="fas fa-edit fa-lg"></i></a> '.
                                    '<a href="semester_actions.php?action='.DELETE_ACTION.'&id='.$myrow['sem_id'].'" title="Delete semester" class="delete-button button"><i class="fas fa-trash-alt fa-lg"></i></a>'.
                                    "</td>";
                            echo '</tr>';                                                                   
                        }//end of loop
                    }
                    else
                    {
                        echo '<tr><td colspan=2 align=center>No record found!</td></tr>';
                    }
                ?>
            </table>
        </div>
    </form>
<?php
    include_once '../common_html_php_code/footer.php';
?>
