<?php 
    include_once '../common_html_php_code/header.php';
    $action = (int)((isset($_GET['action'])) ? sanitize($conn, $_GET['action']): ADD_ACTION);
    $sem_name = '';
    
    if($action == DELETE_ACTION){    
        delete_record($_GET, $conn, "semester_master", "sem_id", "semester.php");
        exit();
        
    }else if($action == UPDATE_ACTION){
        $sem_id = (isset($_GET['id'])) ? sanitize($conn, $_GET['id']): 0;
        $result = mysqli_query($conn, "SELECT * FROM semester_master WHERE sem_id='$sem_id' ");
        while($myrow = mysqli_fetch_assoc($result))
        {
            $sem_name = $myrow["sem_name"];
        }
    }
    
    
    if(isset($_POST['submit']))
    {
        $sem_name = array_key_exists('sem_name', $_POST) ? sanitize($conn, $_POST['sem_name']) : '';
        $sem_id = array_key_exists('sem_id', $_POST) ? sanitize($conn, $_POST['sem_id']) : '';
        $action = sanitize($conn, $_POST['submit']);
        
        if(empty($sem_name)){
            $_SESSION['error_msg'] = "Please enter semester name.";            
        }
        else{ 
            if($action == ADD_ACTION){
                $dup = "select * from semester_master where sem_name='".$sem_name."'";
                $dup_res = mysqli_query($conn, $dup) or die(mysqli_error($conn));
                if(mysqli_num_rows($dup_res) == 1)
                {
                    $_SESSION['error_msg'] = "Semester name is already available in table."; 
                }
                else
                {
                    //inset record
                    mysqli_query($conn, "INSERT INTO semester_master (sem_name) VALUES ('$sem_name')");                
                    $_SESSION['success_msg'] = "Semester is added Successfully!";                
                    header( "refresh:0;url=semester.php" );
                    exit();
                }
            }
            else if($action == UPDATE_ACTION){
                //check duplication
                $dup = "select * from semester_master where sem_name='".$sem_name."' and sem_id!=".$sem_id;
                $dup_res = mysqli_query($conn, $dup) or die(mysqli_error($conn));
                if(mysqli_num_rows($dup_res) == 1)
                {                
                    $_SESSION['error_msg'] = "Semester name is already available in table.";                
                }
                else
                {                                                       
                    mysqli_query($conn, "UPDATE semester_master SET sem_name='$sem_name' WHERE sem_id='$sem_id'");                
                    $_SESSION['success_msg'] = "Semester is updated successfully!";            
                    header( "refresh:0;url=semester.php" );
                    exit();
                }
            }
        }
    }
    
    ShowSessionMsg();
    include_once 'semester_form.php';
    include_once '../common_html_php_code/footer.php';
?>
<script language="javascript" type="text/javascript">
    function chkForm()
    {
        if ( $("#id_sem_name").val().length < 1 )
        {
            alert("Enter semester name");	
            $("#id_sem_name").focus();		
            return false;
        }            
    }
</script>