<?php 
    include_once("includes/common_imports.php");
    $sql="select remark from feedback_master where feed_id=".$_GET['feed_id'];
    $res=mysqli_query($conn, $sql) or die(mysqli_error($conn));
    $row=mysqli_fetch_array($res);
    echo $row['remark'];
?>