<table width="100%">
    <tr>
        <td align="left" valign="top">&nbsp;</td>
        <td align="right">
            <font face="Times New Roman, Times, serif" size="-1" >Feedback Pro (Beta)<br/>Developed By: Shrenik Patel<br/>shrenik181986@gmail.com</font>
        </td>
    </tr>
</table>