<?php 
    include_once '../common_html_php_code/header.php';
    
    if(isset($_POST['action']) && $_POST['action'] == DELETE_ACTION){
        delete_record($_POST, $conn, "branch_master", "b_id", "branch.php");
        exit();
    }
    
    ShowSessionMsg();
?>  
    <form method="post" class="form" action="<?php echo $_SERVER['REQUEST_URI'] ?>" id="id_form">
        <h2>
            <a href='branch_actions.php' class="btn btn-primary" ><i class="fas fa-plus fa-sm"></i> Add branch</a>
            <button type="submit" class="btn btn-danger" name="action" id="id_deletebtn" value="<?php echo DELETE_ACTION ?>">Delete selected</button>
        </h2>
        <div class="table-responsive">
            <table class="table table-striped table-sm">
                <thead class="thead-dark">
                    <tr>
                        <th><input type='checkbox' name="select-all" id="select-all" /></th>
                        <th><b>Branch Name</b></th>
                        <th><b>Actions</b></th>
                    </tr>
                </thead>

                <?php
                    $group_by = mysqli_query($conn, "SELECT distinct(college_id) FROM branch_master  ORDER BY college_id ASC, b_id ASC");                       
                    while($group_c_id = mysqli_fetch_array($group_by))
                    {
                        echo '<tr><td colspan=3 align=center><b>'.college_name($conn, $group_c_id['college_id']).'</b></td></tr>';

                        $result = mysqli_query($conn, "SELECT * FROM branch_master where college_id=".$group_c_id['college_id']." ORDER BY b_id");
                        //$i=1;
                        if(mysqli_num_rows($result) > 0)
                        {
                            while($myrow = mysqli_fetch_array($result))
                            {
                                echo '<tr>';
                                //echo "<td>".$i."</td>";$i++;
                                echo "<td><input type='checkbox' name='id[ ]' value='".$myrow['b_id']."' /></td>";
                                echo "<td>".$myrow['b_name']."</td>";
                                echo "<td>".
                                        '<a href="branch_actions.php?action='.UPDATE_ACTION.'&id='.$myrow['b_id'].'" title="Edit branch" class="button"><i class="fas fa-edit fa-lg"></i></a> '.
                                        '<a href="branch_actions.php?action='.DELETE_ACTION.'&id='.$myrow['b_id'].'" title="Delete branch" class="delete-button button"><i class="fas fa-trash-alt fa-lg"></i></a>'.
                                    "</td>";
                                echo '</tr>';
                            }
                        }
                        else
                        {
                            echo '<tr><td colspan=2 align=center>No record found!</td></tr>';
                        }
                    }
                ?>
            </table>
        </div>
    </form>
<?php 
    include_once '../common_html_php_code/footer.php';
?>
