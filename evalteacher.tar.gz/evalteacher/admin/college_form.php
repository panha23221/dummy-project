<h1 class="h2"><?php echo ($action == UPDATE_ACTION) ? UPDATE_ACTION_TEXT : ADD_ACTION_TEXT ?> College</h1>  
<form method="post" class="form" action="<?php echo $_SERVER['REQUEST_URI'] ?>" onsubmit="return chkForm();">
    <?php if ($action == UPDATE_ACTION){ ?>
        <input type="hidden" name="college_id" value="<?php echo $college_id ?>">
    <?php } ?>
    <div class="form-group">
        <label class="control-label col-sm-2">College Name</label>
        <div class="col-sm-4">
            <input type="text" class="form-control" id="id_college_name" name="college_name" placeholder="Enter college name" value="<?php echo $college_name ?>" onkeypress="return isCharOnly(event);"/>
        </div>
    </div>
    <div class="form-group">
        <div class="col-sm-offset-2 col-sm-4">
            <button type="submit" class="btn btn-default" name="submit" id="id_submit" value="<?php echo $action ?>"><?php echo ($action == UPDATE_ACTION) ? UPDATE_ACTION_TEXT : ADD_ACTION_TEXT ?></button>
            <a href='college.php' class="btn btn-danger">Back</a>
        </div>
    </div>
</form>