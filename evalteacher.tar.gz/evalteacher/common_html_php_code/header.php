<?php
//////////////////////////////////////////////////////////////////*****/////////////////////////////////////////////////////////////////////////////////////
//                                                          Feedback Pro v1																			 //
//                                                     Faculty Evaluation System																		 //
//                                                     Developed By Shrenik Patel																		 //			
//                                                          July 27, 2009																				 //
//																																						 //		
//  Tis program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by 				 //
//  the Free Software  Foundation; either version 2 of the License, or (at your option) any later version.												 //
//																																						 //
//  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or      //
//  FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.																 //
//																																						 //
//////////////////////////////////////////////////////////////////*****//////////////////////////////////////////////////////////////////////////////////////


define("ADD_ACTION", 1);
define("UPDATE_ACTION", 2);
define("DELETE_ACTION", 3);

define("ADD_ACTION_TEXT", "Add");
define("UPDATE_ACTION_TEXT", "Update");
define("DELETE_ACTION_TEXT", "Delete");


//production evalteac_demo
$IMPORT_PREFIX = '';
$ADD_ADMIN_PREFIX = 'admin/';

if (strpos($_SERVER['REQUEST_URI'], "/admin/") !== false) {
    // for admin pages add prefix
    global $IMPORT_PREFIX, $ADD_ADMIN_PREFIX;
    $IMPORT_PREFIX = '../';
    $ADD_ADMIN_PREFIX = '';
}

include_once($ADD_ADMIN_PREFIX."includes/common_imports.php");

$page = basename($_SERVER['PHP_SELF']);
$aline = "center";
$main_table_display = true;

switch ($page){
    case 'index.php':
        $title= 'Login';
        $description = 'login';
        $main_table_display = false;
        break;
    
    case 'login_success.php':
        $title= 'Admin Home';
        $description = 'system description';
        $aline = "left";
        break;
    
    // college
    case 'college.php':
        $title= 'List of Colleges';
        $description = 'List of colleges';    
        break;
    
    case 'college_actions.php':
        $title= 'Add-Update-Delete College Actions';
        $description = 'add-update-delete college detail';       
        break;
    
    // Branch
    case 'branch.php':
        $title= 'List of Branches';
        $description = 'list of branches for each college';        
        break;
    
    case 'branch_actions.php':
        $title= 'Branches actions';
        $description = 'add-update-delete branch detail';
        break;
    
    // batch
    case 'batch.php':
        $title= 'List of Batches';
        $description = 'list of batches';
        break;
   
    case 'batch_actions.php':
        $title= 'Add-Update-Delete Batch';
        $description = 'add-update-delete batch detail';
        break;
    
    // Division
    case 'division.php':
        $title= 'List of Division';
        $description = 'list of division';
        break;
    
    case 'division_actions.php':
        $title= 'Add-Update-Delete division';
        $description = 'add-update-delete division detail';
        break;
    
    // Semester
    case 'semester.php':
        $title= 'List of Semester';
        $description = 'list of semester';
        break;
    
    case 'semester_actions.php':
        $title= 'Add-Update-Delete semester';
        $description = 'add-update-delete semester detail';
        break;
    
    // Faculty
    case 'faculty.php':
        $title= 'List of Faculties';
        $description = 'list of faculty';
        break;
    
    case 'faculty_actions.php':
        $title= 'Add-Update-Delete faculties';
        $description = 'add-update-delete faculty detail';
        break;
   
    // Subject
    case 'subject.php':
        $title= 'List of Subjects';
        $description = 'list of subjects';
        break;
    
    case 'subject_actions.php':
        $title= 'Add-Update-Delete subjects';
        $description = 'add-update-delete subject detail';
        break;
    
    // Feedback questions
    case 'feed_ques.php':
        $title= 'Feedback questions';
        $description = 'list of feedback questions';
        break;
   
    case 'edit_feed_ques.php':
        $title= 'Update feedback question';
        $description = 'update feedback question detail';
        break;
    
    // Import student csv
    case 'import_student_id.php':
        $title= 'Import Student CSV';
        $description = 'import student details';
        break;
    
    // Student list
    case 'student_list.php':
        $title= 'Student List';
        $description = 'Student list';
        break;
  
    // Student id generator
    case 'student_id.php':
        $title= 'Student ID generator';
        $description = 'Student generator';
        break;
    
    // Change password
    case 'change_passwd.php':
        $title= 'change admin passwd';
        $description = 'change admin passwd';
        break;
    
    // Change password
    case 'feedback.php':
        $title= 'View Submitted Student Feedback';
        $description = 'student feedback';
        break;
    
    // Average Graph Report 
    case 'graph_img_n_data.php':
        $title= 'Average Graph Report';
        $description = 'Average Graph Report';
        break;
    
    // Average Graph Report 
    case 'graph_rating_student_count.php':
        $title= 'Rating matrix';
        $description = 'Question wise rating v/s student count report';
        break;
    
    // Remark 
    case 'popup.php':
        $title= 'Remark';
        $description = 'Remark';
        $main_table_display = false;
        break;
    
    default:
        $title= 'Faculty Evaluation System';
        $description = 'about description here';               
}
?>
<html>
    <head>
        <title><?php echo $title; ?></title>
        <meta name="description" content="<?php echo $description; ?>" >
        <link rel='shortcut icon' type='image/x-icon' href='<?php echo $IMPORT_PREFIX ?>includes/favicon/favicon.ico'  />
        
        <link rel="stylesheet" type="text/css" href="<?php echo $IMPORT_PREFIX ?>static-files/fontawesome/css/all.css" />
        <link rel="stylesheet" type="text/css" href="<?php echo $IMPORT_PREFIX ?>static-files/bootstrap-4.3.1/css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="<?php echo $IMPORT_PREFIX ?>static-files/css/style.css" />
        <link rel="stylesheet" type="text/css" href="<?php echo $IMPORT_PREFIX ?>static-files/mdb-icon/css/mdb.min.css" />
        <link rel="stylesheet" type="text/css" href="<?php echo $IMPORT_PREFIX ?>static-files/mdb-icon/css/style.css" />
        
        <script language="javascript" type="text/javascript" src="<?php echo $IMPORT_PREFIX ?>static-files/js/jquery.js"></script>
        <script language="javascript" type="text/javascript" src="<?php echo $IMPORT_PREFIX ?>static-files/js/jquery.flot.js"></script>
        
        <script src="<?php echo $IMPORT_PREFIX ?>static-files/bootstrap-4.3.1/js/bootstrap.min.js"></script>

        <script language="javascript" type="text/javascript" src="<?php echo $IMPORT_PREFIX ?>static-files/js/feedback.js"></script>        
    </head>
    <body class="app sidebar-show aside-menu-show">
        <?php
            
            include_once $IMPORT_PREFIX.'common_html_php_code/admin_menu.php';
            
            if($main_table_display){                                                
        ?>                     
            <div class="container-fluid">
                <div class="row">
                    
                    <main role="main" class="col-md-12 ml-sm-auto col-lg-12 pt-3 px-4">
                        <div class="row">&nbsp;</div>
                        <div class="row">&nbsp;</div>
        <?php                        
            }
        ?>
        