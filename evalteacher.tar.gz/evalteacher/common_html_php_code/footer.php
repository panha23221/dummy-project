<?php 
    if($main_table_display){
?>
                </div>
            </main>
        </div>
    </div>
    <blockquote class="blockquote text-center">
        <footer>
            <p class="card-text"> Shrenik Patel &#9786; shrenik181986@gmail.com</p>
        </footer>
    </blockquote>
           
<?php
    }
?>
    </body>
</html>
<script language="javascript" type="text/javascript">
    
    
    $(".delete-button").click(function(){
        if(confirm("Are you sure you want to delete this?")){                        
            window.location.href = $(this).attr("href");
            //alert($(this).attr("href"));
            //return false;
        }
        else{
            return false;
        }
    });
</script>