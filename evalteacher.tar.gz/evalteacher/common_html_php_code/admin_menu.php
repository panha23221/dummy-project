<header class="app-header navbar">
    <div class="navbar navbar-expand-md navbar-dark bg-dark fixed-top"> 
        <a class="navbar-brand" href="<?php echo (isset($_SESSION['myusername'])) ? 'login_success.php' : (isset($_SESSION['student_id']) ? 'feedback_form.php' : '#') ?>">Faculty Evaluation</a>
         <?php 
            if(isset($_SESSION['myusername']))
            { 
        ?>      
                <div class="collapse navbar-collapse" id="navbarCollapse">
                    <ul class="navbar-nav mr-auto">

                        <li class="nav-item dropdown">
                            <a class="nav-item nav-link dropdown-toggle mr-md-2" href="#" id="bd-versions-I" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                Initial
                            </a>
                            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="bd-versions">
                                <a class="dropdown-item" href="college.php">Colleges</a>
                                <a class="dropdown-item" href="branch.php">Branches</a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="batch.php">Batches</a> 
                                <a class="dropdown-item" href="semester.php">Semesters</a>
                                <a class="dropdown-item" href="division.php">Divisions</a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="feed_ques.php">Feedback questions</a>
                            </div>
                        </li>

                        <li class="nav-item dropdown">
                            <a class="nav-item nav-link dropdown-toggle mr-md-2" href="#" id="bd-versions-II" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                Students
                            </a>
                            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="bd-versions">
                                <a class="dropdown-item" href="import_student_id.php">Import csv</a>
                                <a class="dropdown-item" href="student_list.php">Student list</a>

                            </div>
                        </li>                    
                        <li class="nav-item">
                            <a class="nav-link" href="faculty.php">Faculty</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="feedback.php">Feedback</a>
                        </li>

                    </ul>                                                    
                </div>

                <ul class="navbar-nav flex-row ml-md-auto d-none d-md-flex">
                    <li class="nav-item dropdown">
                        <a class="nav-item nav-link dropdown-toggle mr-md-2" href="#" id="bd-versions-III" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                          Admin
                        </a>
                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="bd-versions">
                            <a class="dropdown-item" href="backup_db.php">Backup DB</a>
                            <a class="dropdown-item" href="change_passwd.php">Change Password</a>                        
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="logout.php">Logout</a>
                        </div>
                    </li>
                </ul>                                             

        <?php 
            }
            else if(isset($_SESSION['student_id'])){
        ?>
                <ul class="navbar-nav flex-row ml-md-auto d-none d-md-flex">
                    <li class="nav-item dropdown">
                        <a class="nav-item nav-link dropdown-toggle mr-md-2" href="#" id="bd-versions-III" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                          Welcome, <?php echo $_SESSION['student_id']; ?>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="bd-versions">
                            <a class="dropdown-item" href="change_std_detail.php">Change student detail</a>
                            <a class="dropdown-item" href="change_passwd.php">Change Password</a>                        
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="logout.php">Logout</a>
                        </div>
                    </li>
                </ul>
        <?php 
            }
        ?>
    </div>
</header>