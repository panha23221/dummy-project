function get_branch_list(selected_branch_name, callfrom){
    selected_branch_name = (typeof selected_branch_name !== 'undefined') ?  selected_branch_name : 0;
    callfrom = (typeof callfrom !== 'undefined') ?  callfrom : 0;
    
    $.ajax({
        url: "./response.php",
        type: "POST",
        data: {
            'college_id': $("#id_college_name").val(),            
            'get_branch_list': true,
            'selected_branch_name': selected_branch_name,
            'callfrom': callfrom,
        },
        success: function(res){
            //console.log(res);
            //alert(res);
            $("#id_branch_dropdown_div").html(res);                      
        },
        error: function(xhr, status, error){
            //alert(e.message);
            //console.log(xhr.responseText);
        }
    });
    return false;
}

function get_faculty_list(selected_faculty_name) 
{   
    selected_faculty_name = (typeof selected_faculty_name !== 'undefined') ?  selected_faculty_name : 0;
    //alert('hi');
    $.ajax({
        url: "./admin/response.php",
        type: "POST",
        data: {
            'college_id': $("#id_college_name").val(),
            'batch_id': $("#id_batch_name").val(),
            'branch_id': $("#id_branch_name").val(),
            'sem_id': $("#id_sem_name").val(),
            'division_id': $("#id_division_name").val(),
            'get_faculty_list': true,
            'selected_faculty_name': selected_faculty_name,
            'roll_no': $("#id_roll_no").val(),
        },
        success: function(res){
            console.log(res);
            //alert(res);
            $("#id_faculty_dropdown_div").html(res);
            $("#id_subject_dropdown_div").html("");
        },
        error: function(xhr, status, error){
            alert(xhr.responseText);
            //console.log(xhr.responseText);
        }
    });
    return false;
}

function get_subjects()
{
    selected_subject_name = (typeof selected_subject_name !== 'undefined') ?  selected_subject_name : 0;
    $.ajax({
        url: "./admin/response.php",
        type: "POST",
        data: {
            'college_id': $("#id_college_name").val(),
            'batch_id': $("#id_batch_name").val(),
            'branch_id': $("#id_branch_name").val(),
            'sem_id': $("#id_sem_name").val(),
            'division_id': $("#id_division_name").val(),
            'f_id': $("#id_faculty_name").val(),
            'get_subject_list': true,
            'selected_subject_name': selected_subject_name,
            'roll_no': $("#id_roll_no").val(),
        },
        success: function(res){
            //alert(res);
            //console.log(res);
            $("#id_subject_dropdown_div").html(res);
        },
        error: function(e){
            //alert(e.message);
            //console.log(e.message);
        }
    });
    return false;
}


function get_all_faculty_list(selected_faculty_name, callfrom) 
{   
    selected_faculty_name = (typeof selected_faculty_name !== 'undefined') ?  selected_faculty_name : 0;
    callfrom = (typeof callfrom !== 'undefined') ?  callfrom : 0;
    
    $.ajax({
        url: "./response.php",
        type: "POST",
        data: {
            'college_id': $("#id_college_name").val(),
            'batch_id': $("#id_batch_name").val(),
            'branch_id': $("#id_branch_name").val(),
            'sem_id': $("#id_sem_name").val(),
            'division_id': $("#id_division_name").val(),
            'get_all_faculty_list': true,
            'selected_faculty_name': selected_faculty_name,
            'callfrom': callfrom
        },
        success: function(res){
            //console.log(res);
            //alert(res);
            $("#id_faculty_dropdown_div").html(res);
            $("#id_subject_dropdown_div").html("");
        },
        error: function(e){
            //alert(e.message);
            //console.log(e.message);
        }
    });
    return false;
}

function get_all_subjects(selected_subject_name, selected_faculty_name, selected_branch_name, callfrom)
{
    var selected_subject_name = (typeof selected_subject_name !== 'undefined') ?  selected_subject_name : 0;
    var selected_faculty_name = (typeof selected_faculty_name !== 'undefined') ?  selected_faculty_name : 0;
    var f_id = (typeof $("#id_faculty_name").val() !== 'undefined') ?  $("#id_faculty_name").val() : selected_faculty_name;
    var branch_id = (typeof $("#id_branch_name").val() !== 'undefined') ?  $("#id_branch_name").val() : selected_branch_name;
    callfrom = (typeof callfrom !== 'undefined') ?  callfrom : 0;
    $.ajax({
        url: "./response.php",
        type: "POST",
        data: {
            'college_id': $("#id_college_name").val(),
            'batch_id': $("#id_batch_name").val(),
            'branch_id': branch_id,
            'sem_id': $("#id_sem_name").val(),
            'division_id': $("#id_division_name").val(),
            'f_id': f_id,
            'get_all_subject_list': true,
            'selected_subject_name': selected_subject_name,
            'callfrom': callfrom
            
        },
        success: function(res){
            //alert(res);
            //console.log(res);
            $("#id_subject_dropdown_div").html(res);
        },
        error: function(e){
            alert(e.message);
            console.log(e.message);
        }
    });
    return false;
}

function isCharOnly(e)
{
    var unicode=e.charCode? e.charCode : e.keyCode
    //if (unicode!=8 && unicode!=9)
    //{ //if the key isn't the backspace key (which we should allow)
             //disable key press
            if (unicode==45)
                    return true;
            if (unicode>48 && unicode<57) //if not a number
                    return false
    //}
}
function isNumberOnly(e)
{
    var unicode=e.charCode? e.charCode : e.keyCode
    if (unicode!=8 && unicode!=9)
    { 
        //if the key isn't the backspace key (which we should allow)
        //disable key press
        //if (unicode==45)
        //	return true;
        if (unicode<48||unicode>57) //if not a number
            return false
    }
}

$(function(){
    $('#select-all').click(function(event) { 		
        if(this.checked) {
            // Iterate each checkbox
            $(':checkbox').each(function() {
                this.checked = true;                        
            });
        }
        else {
            // Iterate each checkbox
            $(':checkbox').each(function() {
                this.checked = false;
            });
        }
    });
    $("#id_deletebtn").click(function() {
        var error = false;
        if ($("#id_form input:checkbox:checked").length <= 0)
        {
            alert("Select atlest one record to delete.");
            error = true;
        }
        if (!error) {
            if(confirm("Are you sure you want to delete?")){
                $("#id_form").submit();
            }

        }else{
            return false;
        }
    });
});