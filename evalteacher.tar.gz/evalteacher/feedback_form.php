<?php
    include_once './common_html_php_code/header.php';
    if(isset($_POST['submit']))
    {
        $roll_no = sanitize($conn, $_POST['roll_no']);
        $college_id = sanitize($conn, $_POST['college_name']);
        $branch_id = sanitize($conn, $_POST['branch_name']);
        $batch_id = sanitize($conn, $_POST['batch_name']);
        $sem_id = sanitize($conn, $_POST['sem_name']);
        $division_id = sanitize($conn, $_POST['division_name']);
        $fac_id = sanitize($conn, $_POST['faculty_name']);
        $sub_id = sanitize($conn, $_POST['subject_name']);

        //feedback no
        $check_feedback_no = "select feedback_no from batch_master where batch_id='$batch_id'";
        $res_feedback_no = mysqli_query($conn, $check_feedback_no) or die(mysqli_error($conn));
        $result = mysqli_fetch_array($res_feedback_no);

        $sql = "select * from feedback_master where roll_no='$roll_no' and ".
               "college_id='$college_id' and b_id='$branch_id' and f_id='$fac_id' and ".
               "sub_id='$sub_id' and sem_id='$sem_id' and batch_id='$batch_id' and ".
               "division_id='$division_id' and feedback_no='".$result['feedback_no']."'";
        //echo $sql;
        $res = mysqli_query($conn, $sql) or die(mysqli_error($conn));

        //echo mysqli_num_rows($res);
        //exit;
        if(mysqli_num_rows($res) >= 1)
        {
            $_SESSION['error_msg'] = "Feedback is already submited by this '$roll_no' roll no for this subject. Please select another faculty or another subject.";   
        }
        else
        {
            //$sql_insert="insert into feedback_master (roll_no, b_id, batch_id, feedback_no, sem_id, f_id, sub_id, division_id, ans1, ans2, ans3, ans4, ans5, ans6, ans7, ans8, ans9, ans10, ans11,ans12, ans13, ans14, ans15, remark, feed_date) values ('".$_POST['roll_no']."','".$_POST['b_name']."','".$_POST['batch_name']."','".$result['feedback_no']."','".$_POST['sem_name']."','".$_POST['fac_name']."','".$_POST['sub_name']."', '".$_POST['division']."', '".$_POST['ans_1']."','".$_POST['ans_2']."','".$_POST['ans_3']."','".$_POST['ans_4']."','".$_POST['ans_5']."','".$_POST['ans_6']."','".$_POST['ans_7']."','".$_POST['ans_8']."','".$_POST['ans_9']."','".$_POST['ans_10']."','".$_POST['ans_11']."','".$_POST['ans_12']."','".$_POST['ans_13']."','".$_POST['ans_14']."','".$_POST['ans_15']."','".$_POST['remark']."','".date('Y-m-d')."')";//,strtotime($_POST['date'])
            $sql_insert="insert into feedback_master (roll_no, college_id, b_id, batch_id, feedback_no, sem_id, f_id, sub_id, division_id, ans1, ans2, ans3, ans4, ans5, ans6, ans7, ans8, ans9, ans10, ans11,ans12, ans13, ans14, ans15, remark, feed_date) ".
                " values ('$roll_no','$college_id','$branch_id','$batch_id','".$result['feedback_no']."','$sem_id','$fac_id','$sub_id', ".
                " '$division_id', '".$_POST['ans_1']."','".$_POST['ans_2']."','".$_POST['ans_3']."','".$_POST['ans_4']."','".$_POST['ans_5']."','".$_POST['ans_6']."','".$_POST['ans_7']."','".$_POST['ans_8']."','".$_POST['ans_9']."','".$_POST['ans_10']."',0,0,0,0,0,'".$_POST['remark']."','".date('Y-m-d')."')";
            mysqli_query($conn, $sql_insert) or die(mysqli_error($conn));
            $_SESSION['success_msg'] = "Feedback is submited successfully!";
        }
    }
    ShowSessionMsg();
?>  
<div class="row justify-content-md-center">
    
    <div class="col-9">
        <div class="row ">
            <div class="col-12" align="center">
                <h1>Faculty Evaluation</h1>
            </div>
        </div>
        <?php
            $sel_para = "select distinct std.id, std.roll_no, std.first_name, std.last_name, std.batch_id, college.c_id, college.c_name,".
                " batch.batch_name, std.branch_id, branch.b_name as branch_name, std.sem_id, sem.sem_name, std.division_id, dm.division "
                ." from student_master AS std "
                ." inner join college_master as college on std.college_id = college.c_id "
                ." inner join batch_master as batch on std.batch_id = batch.batch_id "
                ." inner join branch_master as branch on std.branch_id = branch.b_id "
                ." inner join semester_master as sem on std.sem_id = sem.sem_id "
                ." inner join division_master as dm on std.division_id = dm.id "
                ." where roll_no='".$_SESSION['student_id']."'";
            //echo $sel_para;
            $res_para = mysqli_query($conn, $sel_para) or die(mysqli_error($conn));
            $result_para = mysqli_fetch_array($res_para);
        ?>
        <div class="row alert alert-dark">
            <div class="col-2"><b>College</b> - <?php echo $result_para['c_name'];?></div>
            <div class="col-4"><b>Branch</b> - <?php echo $result_para['branch_name'];?></div>
            <div class="col-2"><b>Batch</b> - <?php echo $result_para['batch_name'];?></div>
            <div class="col-2"><b>Semester</b> - <?php echo $result_para['sem_name'];?></div>
            <div class="col-2"><b>Division</b> - <?php echo $result_para['division'];?></div>
        </div>
        <form action="<?php echo $_SERVER['PHP_SELF'] ?>" class="form" method="post" name="feedback_form" id="id_feedback_form">
            
            <input type="hidden" name="college_name" id="id_college_name" value="<?php echo $result_para['c_id']?>"/>
            <input type="hidden" name="batch_name" id="id_batch_name" value="<?php echo $result_para['batch_id']?>"/>
            <input type="hidden" name="branch_name" id="id_branch_name" value="<?php echo $result_para['branch_id']?>"/>
            <input type="hidden" name="sem_name" id="id_sem_name" value="<?php echo $result_para['sem_id']?>"/>
            <input type="hidden" name="division_name" id="id_division_name" value="<?php echo $result_para['division_id']?>"/>
            <input type="hidden" name="roll_no" id="id_roll_no" value="<?php echo $_SESSION['student_id']; ?>"/>
            
            <div class="row align-center">
                <div class="col">
                    <label><b>Faculty</b></label>
                    <div align="left" id="id_faculty_dropdown_div"></div>
                </div>
                <div class="col">
                    <label><b>Subject</b></label>
                    <div id="id_subject_dropdown_div"></div>
                </div>
            </div>
            <div class="row ">
                <div class="col-12" align="center">&nbsp;</div>
            </div>
            <div class="row ">
                <div class="col-12" align="center">
                    <b>Note: Enter Rating from 1 to <?php echo $MAX_RATING;?>.</b>
                </div>
            </div>
                    
                        
            <div class="table-responsive">
                <table class="table table-striped table-sm" >
                    <thead class="thead-dark">
                        <tr>
                            <th><b>No</b></th>		 
                            <th><b>Questions</b></th>
                            <th><b>Rating</b></th>
                        </tr>
                    </thead>
                    <?php
                        $sql_que = "select * from feedback_ques_master";
                        $res_que = mysqli_query($conn, $sql_que) or die(mysqli_error($conn));
                        $i = 1;
                        $tab_ind = 1;
                        while($row_que=mysqli_fetch_array($res_que))
                        {
                            echo "<tr>";
                            echo "<td><b>".$i."</b></td>";
                            echo "<td><b>".$row_que['ques']."</b></td>";
                            echo "<td>".
                                    "<input type=\"text\" class=\"form-control\" name=\"ans_$i\" size=\"1\" onkeypress=\"return isNumberRatingOnly(event);\" maxlength=\"1\" tabindex=\"$tab_ind\" />".
                                "</td>";
                            $tab_ind++;
                            echo "</tr>";$i++;
                        }
                    ?>		  
                    <tr>
                        <td><b>Remark</b></td>
                        <td colspan="2"><textarea class="form-control" name="remark" onkeypress="return isCharOnly(event);" tabindex="16"></textarea></td>
                    </tr>		  
                    <tr>
                        <td colspan="2"  class="rounded-foot-left" align="center">
                            <input class="btn btn-blue" type="submit" name="submit" id="id_submit" value="Submit"/>&nbsp;
                            <input class="btn btn-danger" type="reset" name="reset" value="Reset"/>
                        </td>
                        <td align="center" class="rounded-foot-right"></td>
                    </tr>			
                </table>
            </div>                        
               
        </form>
    </div>
</div>
<?php           
    include_once './common_html_php_code/footer.php';
?>

<script language="javascript" type="text/javascript">
    
    function isNumberRatingOnly(e)
    {
        var unicode = e.charCode? e.charCode : e.keyCode
        if (unicode!=8 && unicode!=9)
        { //if the key isn't the backspace key (which we should allow)
            //disable key press
            //if (unicode==45)
            //	return true;
            var t = parseInt("49") + parseInt("<?php echo $MAX_RATING;?>") - 1;
            if (unicode < 49 || unicode > t ) //if not a number
                   return false
        }
    }
    get_faculty_list();

    $("#id_submit").click(function(){
        var error = false;

        if ($("#id_faculty_name").val() == 0 )
        {
            alert("Select Faculty Name.");			
            $("#id_faculty_name").focus();
            return false;
        }
        if ($("#id_subject_name").val() == 0 )
        {
            alert("Select Subject");
            $("#id_subject_name").focus();			
            return false;
        }

        for(i=1;i<=10;i++)
        {
            if(eval("document.feedback_form.ans_"+i).value == '')
            {
                alert("Enter rating in question number "+i+".");
                eval("document.feedback_form.ans_"+i).focus();	
                return false;
            }
            if(eval("document.feedback_form.ans_"+i).value < 1 || eval("document.feedback_form.ans_"+i).value > <?php echo $MAX_RATING;?>)
            {
                alert("Enter rating from 1 to <?php echo $MAX_RATING;?>.");
                eval("document.feedback_form.ans_"+i).focus();	
                return false;
            }
        }

    });	
</script>