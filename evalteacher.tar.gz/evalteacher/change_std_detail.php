<?php 
    include_once './common_html_php_code/header.php';
    if(isset($_POST['submit']))
    {
        $f_name = sanitize($conn, $_POST['f_name']);
        $l_name = sanitize($conn, $_POST['l_name']);
        $email_id = sanitize($conn, $_POST['email_id']);
        $sem_id = sanitize($conn, $_POST['sem_name']);
        $div_id = sanitize($conn, $_POST['div_name']);
        $sql = "UPDATE student_master SET email_id = '$email_id', first_name = '$f_name', last_name = '$l_name', sem_id = '$sem_id', division_id = '$div_id' WHERE roll_no='".$_SESSION['student_id']."'";		
        $result = mysqli_query($conn, $sql) or die('error in query');

        $_SESSION['success_msg'] = "Detail updated Successfully!";

    }

    $f_name = '';
    $l_name = '';
    $email_id = '';
    $student_id = $_SESSION['student_id'];
    $result = mysqli_query($conn, "SELECT * FROM student_master WHERE roll_no='$student_id' ");
    while($myrow = mysqli_fetch_assoc($result))
    {
        $f_name = $myrow["first_name"];
        $l_name = $myrow["last_name"];
        $email_id = $myrow["email_id"];
        $sem_id = $myrow["sem_id"];
        $div_id = $myrow["division_id"];
    }
    ShowSessionMsg();
?>
    <h1 class="h2">Change detail</h1>
    <form method="post" action="<?php echo $_SERVER['PHP_SELF'] ?>" name="edit_detail">
        <div class="form-group">
            <label class="control-label col-sm-2"><b>First Name</b></label>
            <div class="col-sm-4">
                <input type="text" class="form-control" id="id_f_name" name="f_name" placeholder="Enter first name" value="<?php echo $f_name;?>" onkeypress="return isCharOnly(event);" />
            </div>
        </div>
        <div class="form-group">
            <label class="control-label col-sm-2"><b>Last Name</b></label>
            <div class="col-sm-4">
                <input type="text" class="form-control" id="id_l_name" name="l_name" placeholder="Enter last name" value="<?php echo $l_name;?>" onkeypress="return isCharOnly(event);" />
            </div>
        </div>
        <div class="form-group">
            <label class="control-label col-sm-2"><b>Email</b></label>
            <div class="col-sm-4">
                <input type="email" class="form-control" id="id_l_name" name="email_id" placeholder="Enter email" value="<?php echo $email_id;?>" onkeypress="return isCharOnly(event);" />
            </div>
        </div>
        <div class="form-group">
            <label class="control-label col-sm-2"><b>Semester</b></label>
            <div class="col-sm-4">
                <?php
                    $sel_sem = "select * from semester_master ";
                    $res_sem = mysqli_query($conn, $sel_sem) or die(mysqli_error($conn));

                    while($sem_combo=mysqli_fetch_array($res_sem))
                    {              
                        $sem_array[] = array('id' => $sem_combo['sem_id'],
                                             'text' => $sem_combo['sem_name']);                  
                    }
                    if(isset($sem_id))
                        $default = $sem_id;
                    else
                        $default = 1;
                    echo tep_draw_pull_down_menu('sem_name', $sem_array, $default, ' id="id_sem_name" class="form-control" ');
                ?>
            </div>
        </div>
        <div class="form-group">
            <label class="control-label col-sm-2"><b>Division</b></label>
            <div class="col-sm-4">
                <?php
                    $sel_div = "select * from division_master ";
                    $res_div = mysqli_query($conn, $sel_div) or die(mysqli_error($conn));

                    while($div_combo=mysqli_fetch_array($res_div))
                    {              
                        $div_array[] = array('id' => $div_combo['id'],
                                             'text' => $div_combo['division']);                  
                    }
                    if(isset($div_id))
                        $default = $div_id;
                    else
                        $default = 1;
                    echo tep_draw_pull_down_menu('div_name', $div_array, $default, ' id="id_div_name" class="form-control" ');
                ?>
            </div>
        </div>
        <div class="form-group">
            <div class="col-sm-offset-2 col-sm-4">
                <button type="submit" class="btn btn-default" name="submit" id="id_submit" value="Update">Update</button>
            </div>
        </div>                            
    </form>
<?php        
    include_once './common_html_php_code/footer.php';
?>